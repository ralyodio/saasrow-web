/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js,ts,jsx,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        "sementic-type-body-m": "var(--sementic-type-body-m-font-family)",
      },
      boxShadow: {
        "cards-short-default": "var(--cards-short-default)",
      },
    },
  },
  plugins: [],
};
