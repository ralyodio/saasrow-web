import React from "react";
import { FaqSection } from "./sections/FaqSection";
import { PricingSection } from "./sections/PricingSection";
import { PromotionSection } from "./sections/PromotionSection";
import { SocialMediaSection } from "./sections/SocialMediaSection";

export const Featured = (): JSX.Element => {
  return (
    <div
      className="bg-neutral-800 w-full min-w-[1440px] h-[2389px] relative"
      data-model-id="2012:405"
    >
      <PromotionSection />
      <div className="absolute top-[244px] left-[380px] w-[770px] h-[121px] flex">
        <p className="mt-[71px] w-[766px] h-[50px] [font-family:'Ubuntu',Helvetica] font-normal text-white text-xl tracking-[0] leading-[25px]">
          SaaSRow is a growing software marketplace with 856,000+ monthly page
          views.
          <br />
          People visit our platform when looking for alternatives or when
          comparing products.
        </p>
      </div>

      <div className="absolute top-[1302px] left-[371px] w-[729px] h-[119px] flex">
        <p className="mt-[69px] w-[725px] h-[50px] [font-family:'Ubuntu',Helvetica] font-normal text-white text-xl text-center tracking-[0] leading-[25px]">
          quick answers to questions you may have. if you don&#39;t see
          what&#39;s on your mind, reach out to us anytime on social media
        </p>
      </div>

      <FaqSection />
      <SocialMediaSection />
      <div className="absolute w-[98.26%] h-[48.18%] top-[7.53%] left-0">
        <div className="absolute w-[81.02%] h-[15.69%] top-[36.16%] left-[12.93%] bg-[#4fffe34c] rotate-[37.69deg] blur-[150px]" />

        <div className="absolute w-[81.02%] h-[15.69%] top-[27.70%] left-[22.59%] bg-[#4fffe34c] rotate-[37.69deg] blur-[150px]" />

        <div className="absolute w-[81.02%] h-[15.69%] top-[46.36%] left-[3.22%] bg-[#e0ff044c] rotate-[37.69deg] blur-[150px]" />

        <div className="absolute w-[81.02%] h-[15.69%] top-[56.61%] left-[-3.60%] bg-[#e0ff044c] rotate-[37.69deg] blur-[150px]" />
      </div>

      <PricingSection />
    </div>
  );
};
