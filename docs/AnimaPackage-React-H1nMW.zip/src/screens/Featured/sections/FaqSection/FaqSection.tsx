import React, { useState } from "react";

interface FaqItem {
  id: number;
  question: string;
  answer?: string;
  isExpanded?: boolean;
}

export const FaqSection = (): JSX.Element => {
  const [expandedId, setExpandedId] = useState<number | null>(1);

  const faqData: FaqItem[] = [
    {
      id: 1,
      question: "How many clicks can I expect?",
      answer:
        "Although we cannot guarantee any specific number of clicks, we can give you an estimate of the number of targeted users we are going to refer to your product. They are: 18 to 34 as of 28 Jun 2024.",
      isExpanded: true,
    },
    {
      id: 2,
      question: "How to launch a Webflow website?",
      isExpanded: false,
    },
    {
      id: 3,
      question: "What countries are SaaSHub's users from?",
      isExpanded: false,
    },
    {
      id: 4,
      question: "Who founded BRIX Templates?",
      isExpanded: false,
    },
    {
      id: 5,
      question:
        "Why SaaSHub's promo price is so low compared to other software marketplaces?",
      isExpanded: false,
    },
    {
      id: 6,
      question: "Who are the Webflow founders?",
      isExpanded: false,
    },
  ];

  const toggleFaq = (id: number) => {
    setExpandedId(expandedId === id ? null : id);
  };

  const renderExpandIcon = (id: number) => {
    const isExpanded = expandedId === id;

    if (isExpanded) {
      return (
        <div className="absolute w-[8.22%] h-[25.00%] top-0 left-[90.99%] rounded-lg bg-[linear-gradient(180deg,rgba(224,255,4,1)_0%,rgba(79,255,227,1)_100%)]">
          <div className="absolute w-[3.56%] h-0 top-[11.90%] left-[93.32%]">
            <img
              className="absolute w-full h-full top-[-15.00%] left-0"
              alt="Collapse"
              src="/img/vector-2.svg"
            />
          </div>
        </div>
      );
    }

    return (
      <div className="absolute w-[8.10%] h-[65.24%] top-0 left-[91.51%] rounded-lg border border-solid border-[#6f5454] bg-[linear-gradient(180deg,rgba(224,255,4,1)_0%,rgba(79,255,227,1)_100%)]">
        <div className="relative w-[43.37%] h-[43.37%] top-[28.31%] left-[28.31%]">
          <img
            className="absolute w-[11.11%] h-[100.00%] top-0 left-[42.78%]"
            alt="Expand vertical"
            src="/img/vector-1.svg"
          />
          <img
            className="absolute w-full h-[11.11%] top-[42.78%] left-0"
            alt="Expand horizontal"
            src="/img/vector-2.svg"
          />
        </div>
      </div>
    );
  };

  return (
    <section className="absolute top-[1470px] left-[143px] w-[1155px] h-[540px]">
      <article
        className="absolute w-[49.01%] h-[42.29%] top-0 left-0 bg-[#4a4a4a] rounded-2xl shadow-cards-short-default cursor-pointer"
        onClick={() => toggleFaq(1)}
        role="button"
        tabIndex={0}
        aria-expanded={expandedId === 1}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            toggleFaq(1);
          }
        }}
      >
        <div className="absolute w-[43.74%] h-[30.74%] top-[7.41%] left-[2.81%]">
          {expandedId === 1 && (
            <p className="absolute w-[84.93%] h-[72.29%] top-[27.71%] left-0 [font-family:'Ubuntu',Helvetica] font-normal text-[#9c9c9c] text-lg tracking-[0] leading-[30px]">
              Although we cannot guarantee any specific number of clicks, we can
              give you an estimate of the number of targeted users we are going
              to refer to your product. They are: 18 to 34 as of 28 Jun 2024.
            </p>
          )}

          <h3 className="absolute w-[80.77%] h-[33.74%] top-[2.63%] left-0 [font-family:'Ubuntu',Helvetica] font-medium text-white text-[22px] tracking-[0] leading-7">
            How many clicks can I expect?
          </h3>

          {expandedId === 1 ? (
            <div className="absolute w-[8.22%] h-[25.00%] top-0 left-[90.99%] rounded-lg bg-[linear-gradient(180deg,rgba(224,255,4,1)_0%,rgba(79,255,227,1)_100%)]">
              <div className="absolute w-[3.56%] h-0 top-[11.90%] left-[93.32%]">
                <img
                  className="absolute w-full h-full top-[-15.00%] left-0"
                  alt="Collapse"
                  src="/img/vector-2.svg"
                />
              </div>
            </div>
          ) : (
            <img
              className="absolute w-[8.25%] h-full top-0 left-[91.36%]"
              alt="Expand"
              src="/img/group-36814.png"
            />
          )}
        </div>
      </article>

      <article
        className="absolute w-[49.01%] h-[22.59%] top-[47.11%] left-0 bg-[#4a4a4a] rounded-2xl shadow-cards-short-default cursor-pointer"
        onClick={() => toggleFaq(3)}
        role="button"
        tabIndex={0}
        aria-expanded={expandedId === 3}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            toggleFaq(3);
          }
        }}
      >
        <div className="relative w-[90.55%] h-[52.14%] top-[32.79%] left-[4.06%]">
          <h3 className="absolute w-[87.41%] h-[88.03%] top-[11.97%] left-0 [font-family:'Ubuntu',Helvetica] font-medium text-white text-[22px] tracking-[0] leading-7">
            What countries are SaaSHub&#39;s users from?
          </h3>

          <div className="absolute w-[8.10%] h-[65.24%] top-0 left-[91.51%] rounded-lg border border-solid border-[#6f5454] bg-[linear-gradient(180deg,rgba(224,255,4,1)_0%,rgba(79,255,227,1)_100%)]">
            <div className="relative w-[43.37%] h-[43.37%] top-[28.31%] left-[28.31%]">
              <img
                className="absolute w-[11.11%] h-[100.00%] top-0 left-[42.78%]"
                alt="Expand vertical"
                src="/img/vector-1.svg"
              />
              <img
                className="absolute w-full h-[11.11%] top-[42.78%] left-0"
                alt="Expand horizontal"
                src="/img/vector-2.svg"
              />
            </div>
          </div>
        </div>
      </article>

      <article
        className="absolute w-[49.01%] h-[22.59%] top-0 left-[50.99%] bg-[#4a4a4a] rounded-2xl shadow-cards-short-default cursor-pointer"
        onClick={() => toggleFaq(2)}
        role="button"
        tabIndex={0}
        aria-expanded={expandedId === 2}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            toggleFaq(2);
          }
        }}
      >
        <div className="relative w-[88.91%] h-[34.02%] top-[32.99%] left-[5.74%]">
          <h3 className="absolute w-[80.08%] h-[67.47%] top-[9.98%] left-0 [font-family:'Ubuntu',Helvetica] font-medium text-white text-[22px] tracking-[0] leading-7">
            How to launch a Webflow website?
          </h3>

          <img
            className="absolute w-[8.25%] h-full top-0 left-[91.36%]"
            alt="Expand"
            src="/img/group-36814.png"
          />
        </div>
      </article>

      <article
        className="absolute w-[49.01%] h-[25.58%] top-[74.42%] left-0 cursor-pointer"
        onClick={() => toggleFaq(5)}
        role="button"
        tabIndex={0}
        aria-expanded={expandedId === 5}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            toggleFaq(5);
          }
        }}
      >
        <div className="absolute w-full h-[88.33%] top-0 left-0 bg-[#4a4a4a] rounded-2xl shadow-cards-short-default" />

        <div className="absolute w-[88.96%] h-[81.09%] top-[18.91%] left-[5.65%]">
          <h3 className="absolute w-[80.04%] h-full top-0 left-0 [font-family:'Ubuntu',Helvetica] font-medium text-white text-[22px] tracking-[0] leading-7">
            Why SaaSHub&#39;s promo price is so low compared to other software
            marketplaces?
          </h3>

          <img
            className="absolute w-[8.24%] h-[37.05%] top-[12.84%] left-[91.36%]"
            alt="Expand"
            src="/img/group-36814-3.png"
          />
        </div>
      </article>

      <article
        className="absolute w-[49.01%] h-[22.59%] top-[27.34%] left-[50.99%] bg-[#4a4a4a] rounded-2xl shadow-cards-short-default cursor-pointer"
        onClick={() => toggleFaq(4)}
        role="button"
        tabIndex={0}
        aria-expanded={expandedId === 4}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            toggleFaq(4);
          }
        }}
      >
        <div className="relative w-[88.91%] h-[34.02%] top-[32.58%] left-[5.74%]">
          <h3 className="absolute w-[80.08%] h-[67.47%] top-[11.18%] left-0 [font-family:'Ubuntu',Helvetica] font-medium text-white text-[22px] tracking-[0] leading-7">
            Who founded BRIX Templates?
          </h3>

          <img
            className="absolute w-[8.25%] h-full top-0 left-[91.36%]"
            alt="Expand"
            src="/img/group-36814-3.png"
          />
        </div>
      </article>

      <article
        className="absolute w-[49.01%] h-[22.59%] top-[54.29%] left-[50.99%] bg-[#4a4a4a] rounded-2xl shadow-cards-short-default cursor-pointer"
        onClick={() => toggleFaq(6)}
        role="button"
        tabIndex={0}
        aria-expanded={expandedId === 6}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            toggleFaq(6);
          }
        }}
      >
        <div className="relative w-[88.91%] h-[34.02%] top-[32.99%] left-[5.74%]">
          <h3 className="absolute w-[80.08%] h-[67.47%] top-[9.98%] left-0 [font-family:'Ubuntu',Helvetica] font-medium text-white text-[22px] tracking-[0] leading-7">
            Who are the Webflow founders?
          </h3>

          <img
            className="absolute w-[8.25%] h-full top-0 left-[91.36%]"
            alt="Expand"
            src="/img/group-36814-3.png"
          />
        </div>
      </article>
    </section>
  );
};
