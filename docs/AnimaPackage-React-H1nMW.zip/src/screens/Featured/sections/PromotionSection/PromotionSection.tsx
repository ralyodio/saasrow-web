import React from "react";

export const PromotionSection = (): JSX.Element => {
  const navigationItems = [
    { label: "Apps", href: "#apps", isHighlighted: false },
    { label: "Tags", href: "#tags", isHighlighted: false },
    { label: "Community", href: "#community", isHighlighted: false },
    { label: "Get Featured", href: "#get-featured", isHighlighted: true },
  ];

  return (
    <header className="absolute top-9 left-[calc(50.00%_-_667px)] w-[1335px] h-[181px]">
      <nav
        className="absolute w-[702px] h-[66px] top-[57px] left-[633px] flex"
        aria-label="Main navigation"
      >
        <div className="flex-1 w-[702px] relative">
          <ul className="absolute w-[75.50%] h-[56.06%] top-[21.21%] left-0 flex items-center justify-between list-none m-0 p-0">
            {navigationItems.map((item, index) => (
              <li
                key={index}
                className={`${index === 0 ? "w-[13.02%]" : index === 1 ? "w-[12.26%] ml-[4.15%]" : index === 2 ? "w-[29.06%] ml-[3.78%]" : "w-[32.45%] ml-[3.72%]"} h-[94.59%] ${index >= 2 ? "mt-[5.41%]" : ""}`}
              >
                <a
                  href={item.href}
                  className={`block ${
                    item.isHighlighted
                      ? "bg-[linear-gradient(180deg,rgba(224,255,4,1)_0%,rgba(79,255,227,1)_100%)] [-webkit-background-clip:text] bg-clip-text [-webkit-text-fill-color:transparent] [text-fill-color:transparent]"
                      : "text-white"
                  } [font-family:'Roboto',Helvetica] font-normal text-3xl tracking-[0] leading-[normal] whitespace-nowrap`}
                >
                  {item.label}
                </a>
              </li>
            ))}
          </ul>

          <div className="absolute w-[21.65%] h-full top-0 left-[78.35%] flex rounded-[500px] bg-[linear-gradient(180deg,rgba(224,255,4,1)_0%,rgba(79,255,227,1)_100%)]">
            <button
              type="button"
              className="flex items-center justify-center ml-[-0.09%] w-[152.13px] mr-[-0.0%] flex-1 [font-family:'Roboto',Helvetica] font-normal text-neutral-800 text-[26px] text-center tracking-[0] leading-[normal] cursor-pointer"
              aria-label="Sign in to your account"
            >
              Sign in
            </button>
          </div>
        </div>
      </nav>

      <img
        className="absolute w-[27.12%] h-[40.33%] top-[26.52%] left-0 object-cover"
        alt="Wiresniff logo"
        src="/img/wiresniff-logo-1.png"
      />
    </header>
  );
};
