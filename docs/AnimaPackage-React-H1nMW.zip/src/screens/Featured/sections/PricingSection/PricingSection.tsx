import React, { useState } from "react";

interface PricingFeature {
  text: string;
  icon: string;
}

interface PricingPlan {
  name: string;
  description: string;
  price: string;
  period: string;
  buttonText: string;
  featuresTitle: string;
  features: PricingFeature[];
  isPopular?: boolean;
}

export const PricingSection = (): JSX.Element => {
  const [billingPeriod, setBillingPeriod] = useState<"yearly" | "monthly">(
    "yearly",
  );

  const pricingPlans: PricingPlan[] = [
    {
      name: "Free",
      description: "Best for personal use",
      price: "$0",
      period: "/month",
      buttonText: "Get started",
      featuresTitle: "What you get:",
      features: [
        { text: "Task Management", icon: "/img/checkmark.svg" },
        { text: "Project Planning", icon: "/img/checkmark-1.svg" },
        { text: "Team Collaboration", icon: "/img/checkmark-2.svg" },
        { text: "Notifications and Reminders", icon: "/img/checkmark-3.svg" },
        { text: "What you get", icon: "/img/checkmark-4.svg" },
      ],
    },
    {
      name: "Basic",
      description: "Best for personal use",
      price: "$8",
      period: "/month",
      buttonText: "Get started",
      featuresTitle: "All free features, plus:",
      features: [
        { text: "Kanban Boards", icon: "/img/checkmark-5.svg" },
        { text: "Gantt Charts", icon: "/img/checkmark-6.svg" },
        { text: "Resource Allocation", icon: "/img/checkmark-7.svg" },
        { text: "Calendar Integration", icon: "/img/checkmark-8.svg" },
        { text: "Progress Tracking", icon: "/img/checkmark-9.svg" },
      ],
    },
    {
      name: "Premium",
      description: "Best for personal use",
      price: "$16",
      period: "/month",
      buttonText: "Get started",
      featuresTitle: "All starter features, plus:",
      features: [
        { text: "Customizable Workflows", icon: "/img/checkmark-10.svg" },
        { text: "Reporting and Analytics", icon: "/img/checkmark-11.svg" },
        { text: "Document Management", icon: "/img/checkmark-12.svg" },
        { text: "Agile Methodology Support", icon: "/img/checkmark-13.svg" },
        { text: "Issue Tracking", icon: "/img/checkmark-14.svg" },
      ],
      isPopular: true,
    },
  ];

  return (
    <section className="absolute w-[1151px] h-[775px] top-[397px] left-[143px] flex flex-col gap-[23px]">
      <div className="ml-[474px] w-[206.74px] h-[74px] flex flex-col gap-[8.1px]">
        <div
          className="w-[204.74px] h-[47.89px] flex gap-[0.5px] bg-[#4a4a4a] rounded-[119.73px]"
          role="tablist"
          aria-label="Billing period selector"
        >
          <button
            role="tab"
            aria-selected={billingPeriod === "yearly"}
            aria-controls="pricing-plans"
            onClick={() => setBillingPeriod("yearly")}
            className={`inline-flex mt-[4.8px] w-[89.31px] h-[38.16px] ml-[4.8px] gap-[11.97px] px-[19.16px] py-[9.58px] rounded-[119.73px] relative items-center justify-center ${
              billingPeriod === "yearly"
                ? "bg-[linear-gradient(180deg,rgba(224,255,4,1)_0%,rgba(79,255,227,1)_100%)]"
                : ""
            }`}
          >
            <span
              className={`relative w-fit mt-[-1.20px] [font-family:'Ubuntu',Helvetica] font-bold text-[16.8px] tracking-[0] leading-[19.3px] whitespace-nowrap ${
                billingPeriod === "yearly" ? "text-neutral-800" : "text-white"
              }`}
            >
              Yearly
            </span>
          </button>

          <button
            role="tab"
            aria-selected={billingPeriod === "monthly"}
            aria-controls="pricing-plans"
            onClick={() => setBillingPeriod("monthly")}
            className={`inline-flex mt-[4.8px] w-[105.31px] h-[38.16px] gap-[11.97px] px-[19.16px] py-[9.58px] rounded-[119.73px] relative items-center justify-center ${
              billingPeriod === "monthly"
                ? "bg-[linear-gradient(180deg,rgba(224,255,4,1)_0%,rgba(79,255,227,1)_100%)]"
                : ""
            }`}
          >
            <span
              className={`relative w-fit mt-[-1.20px] [font-family:'Ubuntu',Helvetica] font-bold text-[16.8px] tracking-[0] leading-[19.3px] whitespace-nowrap ${
                billingPeriod === "monthly" ? "text-neutral-800" : "text-white"
              }`}
            >
              Monthly
            </span>
          </button>
        </div>

        <p className="ml-5 w-[167px] h-[18px] bg-[linear-gradient(180deg,rgba(224,255,4,1)_0%,rgba(79,255,227,1)_100%)] [-webkit-background-clip:text] bg-clip-text [-webkit-text-fill-color:transparent] [text-fill-color:transparent] [font-family:'Ubuntu',Helvetica] font-normal text-transparent text-[14.4px] tracking-[0] leading-[18.0px] whitespace-nowrap">
          <span className="font-bold text-black">Save 15%</span>
          <span className="font-medium text-black"> on yearly plan!</span>
        </p>
      </div>

      <div
        id="pricing-plans"
        className="w-[1151px] h-[678px] relative flex"
        role="list"
      >
        {pricingPlans.map((plan, index) => (
          <article
            key={plan.name}
            role="listitem"
            className={`${index === 0 ? "mt-[35.8px]" : index === 1 ? "mt-[35.8px] ml-[20.5px]" : "ml-[20.8px]"} ${
              index === 2 ? "w-[370px] h-[678px]" : "w-[369.84px] h-[642.09px]"
            } flex relative flex-col bg-[#4a4a4a] rounded-[20px] overflow-hidden ${
              plan.isPopular
                ? "before:content-[''] before:absolute before:inset-0 before:p-[2.57px] before:rounded-[20px] before:[background:linear-gradient(180deg,rgba(224,255,4,1)_0%,rgba(79,255,227,1)_100%)] before:[-webkit-mask:linear-gradient(#fff_0_0)_content-box,linear-gradient(#fff_0_0)] before:[-webkit-mask-composite:xor] before:[mask-composite:exclude] before:z-[1] before:pointer-events-none"
                : ""
            }`}
          >
            {plan.isPopular && (
              <div className="w-[369.84px] h-[35.96px] relative bg-[linear-gradient(180deg,rgba(224,255,4,1)_0%,rgba(79,255,227,1)_100%)]">
                <div className="absolute top-2 left-[119px] [font-family:'Inter',Helvetica] font-semibold text-neutral-800 text-lg tracking-[0] leading-[20.7px] whitespace-nowrap">
                  Most Popular
                </div>
                <img
                  className="absolute top-2 left-[235px] w-[21px] h-[21px]"
                  alt=""
                  src="/img/sparkles.png"
                  aria-hidden="true"
                />
              </div>
            )}

            <div className="flex flex-col items-start gap-[51.37px] pt-[30.82px] pb-[20.55px] px-[20.55px] relative self-stretch w-full flex-[0_0_auto]">
              <header className="inline-flex gap-[41.09px] px-[10.27px] py-0 flex-[0_0_auto] relative flex-col items-start">
                <div className="inline-flex flex-col items-start gap-[5.14px] relative flex-[0_0_auto]">
                  <h3 className="relative w-fit mt-[-1.28px] [font-family:'Ubuntu',Helvetica] font-bold text-white text-3xl tracking-[0] leading-[34.5px] whitespace-nowrap">
                    {plan.name}
                  </h3>
                  <p className="relative w-fit [font-family:'Ubuntu',Helvetica] font-normal text-white text-xl tracking-[0] leading-[25px] whitespace-nowrap">
                    {plan.description}
                  </p>
                </div>

                <div className="inline-flex items-end gap-[5.14px] relative flex-[0_0_auto]">
                  <span className="relative w-fit mt-[-1.28px] [font-family:'Ubuntu',Helvetica] font-bold text-white text-[45px] tracking-[0] leading-[51.7px] whitespace-nowrap">
                    {plan.price}
                  </span>
                  <span className="relative w-fit [font-family:'Ubuntu',Helvetica] font-normal text-white text-[15px] tracking-[0] leading-[17.2px] whitespace-nowrap">
                    {plan.period}
                  </span>
                </div>
              </header>

              <button
                className="all-[unset] box-border flex gap-[12.84px] px-[25.68px] py-[15.41px] self-stretch w-full flex-[0_0_auto] rounded-[100px] bg-[linear-gradient(180deg,rgba(224,255,4,1)_0%,rgba(79,255,227,1)_100%)] relative items-center justify-center cursor-pointer hover:opacity-90 transition-opacity"
                aria-label={`${plan.buttonText} with ${plan.name} plan`}
              >
                <span className="relative w-fit mt-[-1.28px] [font-family:'Ubuntu',Helvetica] font-bold text-neutral-800 text-[20.5px] leading-[23.6px] tracking-[0] whitespace-nowrap">
                  {plan.buttonText}
                </span>
              </button>

              <div className="flex gap-[20.55px] pl-[10.27px] pr-[20.55px] pt-0 pb-[20.55px] self-stretch w-full flex-[0_0_auto] relative flex-col items-start">
                <h4 className="self-stretch mt-[-1.28px] [font-family:'Ubuntu',Helvetica] font-bold text-xl leading-[23.0px] relative text-white tracking-[0]">
                  {plan.featuresTitle}
                </h4>

                <ul className="flex flex-col gap-[20.55px] w-full" role="list">
                  {plan.features.map((feature, featureIndex) => (
                    <li
                      key={featureIndex}
                      className="flex items-center gap-[20.55px] relative self-stretch w-full flex-[0_0_auto]"
                    >
                      <img
                        className="relative w-[30.82px] h-[30.82px]"
                        alt=""
                        src={feature.icon}
                        aria-hidden="true"
                      />
                      <span className="relative flex-1 [font-family:'Ubuntu',Helvetica] font-normal text-white text-lg tracking-[0] leading-[22.5px]">
                        {feature.text}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
};
