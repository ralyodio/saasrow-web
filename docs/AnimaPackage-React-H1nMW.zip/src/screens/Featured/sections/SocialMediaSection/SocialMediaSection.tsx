import React from "react";

export const SocialMediaSection = (): JSX.Element => {
  const navigationLinks = [
    { label: "About us", width: "11.27%", left: "0" },
    { label: "Discover", width: "10.69%", left: "25.02%" },
    { label: "Explore", width: "9.68%", left: "49.69%" },
    { label: "News", width: "6.94%", left: "72.81%" },
  ];

  const footerLinks = [
    { label: "Terms of Service", href: "#terms" },
    { label: "Privacy Policy", href: "#privacy" },
  ];

  return (
    <footer className="absolute top-[2159px] left-[93px] w-[1282px] h-[178px]">
      <div className="absolute w-[100.31%] h-[91.89%] top-0 left-0">
        <p className="absolute w-[21.61%] h-[11.62%] top-[88.38%] left-0 opacity-75 [font-family:'Ubuntu',Helvetica] font-normal text-white text-[16.7px] tracking-[0] leading-[normal] whitespace-nowrap">
          © 2019 SaaSRow. All rights reserved.
        </p>

        <div className="absolute w-[20.76%] h-[11.62%] top-[88.38%] left-[78.25%] [font-family:'Ubuntu',Helvetica] font-normal text-white text-[16.7px] tracking-[0] leading-[normal] whitespace-nowrap">
          <a href="#terms" className="hover:opacity-75 transition-opacity">
            Terms of Service
          </a>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <a href="#privacy" className="hover:opacity-75 transition-opacity">
            Privacy Policy
          </a>
        </div>

        <img
          className="absolute w-[99.60%] h-0 top-[52.59%] left-0"
          alt=""
          src="/img/line-2.svg"
          role="presentation"
        />

        <nav
          className="absolute w-[53.80%] h-[12.85%] top-[2.39%] left-0"
          aria-label="Footer navigation"
        >
          {navigationLinks.map((link, index) => (
            <a
              key={index}
              href={`#${link.label.toLowerCase().replace(/\s+/g, "-")}`}
              className="absolute top-[calc(50.00%_-_11px)] [font-family:'Ubuntu',Helvetica] font-normal text-white text-[19.1px] tracking-[0] leading-[normal] whitespace-nowrap hover:opacity-75 transition-opacity"
              style={{ width: link.width, left: link.left }}
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div
          className="absolute w-[258px] h-[29px] top-0 left-[1024px]"
          aria-label="Social media links"
        >
          <img
            className="w-full h-full"
            alt="Social media icons"
            src="/img/social.png"
          />
        </div>
      </div>

      <img
        className="absolute w-[17.78%] h-[26.17%] top-[73.83%] left-[40.13%] object-cover"
        alt="Wiresniff logo"
        src="/img/wiresniff-logo-1-1.png"
      />
    </footer>
  );
};
