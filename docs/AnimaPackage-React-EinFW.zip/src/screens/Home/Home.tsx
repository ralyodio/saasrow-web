import React from "react";
import { AppListSection } from "./sections/AppListSection";
import { ContentSection } from "./sections/ContentSection";
import { FeaturedAppsSection } from "./sections/FeaturedAppsSection";
import { FooterSection } from "./sections/FooterSection";

export const Home = (): JSX.Element => {
  return (
    <div
      className="bg-neutral-800 w-full min-w-[1440px] h-[2415px] relative"
      data-model-id="2:283"
    >
      <div className="absolute w-[98.26%] h-[47.66%] top-[7.45%] left-0">
        <div className="absolute w-[81.02%] h-[15.69%] top-[36.16%] left-[12.93%] bg-[#4fffe34c] rotate-[37.69deg] blur-[150px]" />

        <div className="absolute w-[81.02%] h-[15.69%] top-[27.70%] left-[22.59%] bg-[#4fffe34c] rotate-[37.69deg] blur-[150px]" />

        <div className="absolute w-[81.02%] h-[15.69%] top-[46.36%] left-[3.22%] bg-[#e0ff044c] rotate-[37.69deg] blur-[150px]" />

        <div className="absolute w-[81.02%] h-[15.69%] top-[56.61%] left-[-3.60%] bg-[#e0ff044c] rotate-[37.69deg] blur-[150px]" />
      </div>

      <FeaturedAppsSection />
      <AppListSection />
      <ContentSection />
      <FooterSection />
    </div>
  );
};
