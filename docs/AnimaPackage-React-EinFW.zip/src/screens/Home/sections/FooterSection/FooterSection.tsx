import React, { useState } from "react";

export const FooterSection = (): JSX.Element => {
  const [email, setEmail] = useState("");

  const navigationLinks = [
    { label: "About us", href: "#about" },
    { label: "Discover", href: "#discover" },
    { label: "Explore", href: "#explore" },
    { label: "News", href: "#news" },
  ];

  const footerLinks = [
    { label: "Terms of Service", href: "#terms" },
    { label: "Privacy Policy", href: "#privacy" },
  ];

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Subscribing email:", email);
  };

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEmail(e.target.value);
  };

  return (
    <footer className="absolute top-[1905px] left-[calc(50.00%_-_637px)] w-[1282px] h-[474px]">
      <div className="absolute w-[100.31%] h-[96.96%] top-0 left-0">
        <section className="absolute h-[51.96%] top-0 left-0 flex px-[31.2px] py-[54.6px] items-start min-w-[99.69%] rounded-[20.61px] bg-[linear-gradient(180deg,rgba(224,255,4,1)_0%,rgba(79,255,227,1)_100%)]">
          <div className="w-[1218px] h-[114px] relative">
            <div className="absolute w-[59.79%] h-full top-0 left-0">
              <h2 className="absolute w-[99.45%] h-[37.98%] top-0 left-0 [font-family:'Ubuntu',Helvetica] font-bold text-black text-[51.5px] tracking-[0] leading-[normal] whitespace-nowrap">
                Subscribe Newsletter
              </h2>

              <p className="absolute w-[72.15%] h-[42.12%] top-[57.88%] left-[4.39%] [font-family:'Ubuntu',Helvetica] font-normal text-black text-[20.6px] tracking-[0] leading-[normal]">
                For the latest in self-hosted news, software, and content
                delivered straight to your inbox every Friday
              </p>
            </div>

            <form
              className="absolute w-[49.07%] h-[56.82%] top-[28.94%] left-[51.09%]"
              onSubmit={handleSubscribe}
              aria-label="Newsletter subscription form"
            >
              <div className="absolute w-full h-[103.09%] top-0 left-0 bg-neutral-800 rounded-[89.93px]" />

              <label htmlFor="newsletter-email" className="sr-only">
                Enter your email
              </label>
              <input
                id="newsletter-email"
                type="email"
                value={email}
                onChange={handleEmailChange}
                placeholder="Enter your email"
                required
                aria-required="true"
                className="absolute w-[56.81%] h-[30.63%] top-[34.80%] left-[4.67%] [font-family:'Ubuntu',Helvetica] font-normal text-white text-lg tracking-[0] leading-[normal] bg-transparent outline-none focus:outline-none"
              />

              <button
                type="submit"
                className="absolute w-[35.18%] h-[77.78%] top-[11.14%] left-[63.18%] rounded-[89.93px] overflow-hidden cursor-pointer transition-opacity hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-black focus:ring-offset-2"
                aria-label="Subscribe to newsletter"
              >
                <div className="absolute w-[100.95%] h-[103.97%] top-0 left-0 rounded-[3.6px] bg-[linear-gradient(180deg,rgba(224,255,4,1)_0%,rgba(79,255,227,1)_100%)]" />

                <span className="absolute w-[56.80%] top-[calc(50.00%_-_10px)] left-[21.86%] [font-family:'Ubuntu',Helvetica] font-medium text-neutral-800 text-lg text-center tracking-[0] leading-[normal]">
                  Subcribe Now
                </span>
              </button>
            </form>
          </div>
        </section>

        <p className="absolute w-[21.61%] h-[4.13%] top-[95.87%] left-0 opacity-75 [font-family:'Ubuntu',Helvetica] font-normal text-white text-[16.7px] tracking-[0] leading-[normal] whitespace-nowrap">
          © 2019 SaaSRow. All rights reserved.
        </p>

        <nav
          className="absolute w-[20.76%] h-[4.13%] top-[95.87%] left-[78.25%] [font-family:'Ubuntu',Helvetica] font-normal text-white text-[16.7px] tracking-[0] leading-[normal] whitespace-nowrap"
          aria-label="Footer legal links"
        >
          {footerLinks.map((link, index) => (
            <React.Fragment key={link.label}>
              <a
                href={link.href}
                className="hover:underline focus:outline-none focus:underline"
              >
                {link.label}
              </a>
              {index < footerLinks.length - 1 && (
                <span aria-hidden="true">
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span>
              )}
            </React.Fragment>
          ))}
        </nav>

        <hr
          className="absolute w-[99.60%] h-0 top-[83.14%] left-0 border-t border-white"
          aria-hidden="true"
        />

        <nav
          className="absolute w-[53.80%] h-[4.57%] top-[65.28%] left-0"
          aria-label="Footer navigation"
        >
          {navigationLinks.map((link, index) => {
            const positions = [
              { left: "0", width: "11.27%" },
              { left: "25.02%", width: "10.69%" },
              { left: "49.69%", width: "9.68%" },
              { left: "72.81%", width: "6.94%" },
            ];

            return (
              <a
                key={link.label}
                href={link.href}
                className="absolute top-[calc(50.00%_-_11px)] [font-family:'Ubuntu',Helvetica] font-normal text-white text-[19.1px] tracking-[0] leading-[normal] whitespace-nowrap hover:underline focus:outline-none focus:underline"
                style={{
                  left: positions[index].left,
                  width: positions[index].width,
                }}
              >
                {link.label}
              </a>
            );
          })}
        </nav>

        <img
          className="absolute w-[258px] h-[29px] top-[296px] left-[1024px]"
          alt="Social media links"
          src="/img/social.png"
        />
      </div>

      <img
        className="absolute w-[17.78%] h-[9.82%] top-[90.18%] left-[40.13%] object-cover"
        alt="Wiresniff logo"
        src="/img/wiresniff-logo-1-1.png"
      />
    </footer>
  );
};
