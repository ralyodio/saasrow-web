import React from "react";

export const FeaturedAppsSection = (): JSX.Element => {
  const navigationItems = [
    { label: "Apps", isActive: true },
    { label: "Tags", isActive: false },
    { label: "Community", isActive: false },
    { label: "Get Featured", isActive: false },
  ];

  return (
    <header className="absolute top-9 left-[calc(50.00%_-_667px)] w-[1335px] h-[181px]">
      <nav
        className="absolute w-[702px] h-[66px] top-[57px] left-[633px] flex"
        aria-label="Main navigation"
      >
        <div className="flex-1 w-[702px] relative">
          <div className="absolute w-[75.50%] h-[56.06%] top-[21.21%] left-0 flex items-center">
            {navigationItems.map((item, index) => {
              const positions = [
                { left: "0", width: "13.02%" },
                { left: "17.17%", width: "12.26%" },
                { left: "33.21%", width: "29.06%", top: "5.41%" },
                { left: "66.04%", width: "32.45%", top: "5.41%" },
              ];

              return (
                <a
                  key={item.label}
                  href={`#${item.label.toLowerCase().replace(" ", "-")}`}
                  className={`absolute h-[94.59%] ${positions[index].top ? `top-[${positions[index].top}]` : "top-0"} [font-family:'Roboto',Helvetica] font-normal text-3xl tracking-[0] leading-[normal] whitespace-nowrap`}
                  style={{
                    left: positions[index].left,
                    width: positions[index].width,
                  }}
                >
                  {item.isActive ? (
                    <span className="bg-[linear-gradient(180deg,rgba(224,255,4,1)_0%,rgba(79,255,227,1)_100%)] [-webkit-background-clip:text] bg-clip-text [-webkit-text-fill-color:transparent] [text-fill-color:transparent]">
                      {item.label}
                    </span>
                  ) : (
                    <span className="text-white">{item.label}</span>
                  )}
                </a>
              );
            })}
          </div>

          <button
            className="absolute w-[21.65%] h-full top-0 left-[78.35%] flex rounded-[500px] bg-[linear-gradient(180deg,rgba(224,255,4,1)_0%,rgba(79,255,227,1)_100%)] cursor-pointer transition-opacity hover:opacity-90"
            aria-label="Sign in to your account"
          >
            <span className="flex items-center justify-center ml-[-0.09%] w-[152.13px] mr-[-0.0%] flex-1 [font-family:'Roboto',Helvetica] font-normal text-neutral-800 text-[26px] text-center tracking-[0] leading-[normal]">
              Sign in
            </span>
          </button>
        </div>
      </nav>

      <img
        className="absolute w-[27.12%] h-[40.33%] top-[26.52%] left-0 object-cover"
        alt="Wiresniff logo"
        src="/img/wiresniff-logo-1.png"
      />
    </header>
  );
};
