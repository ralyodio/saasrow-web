import React, { useState } from "react";

export const AppListSection = (): JSX.Element => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedFilter, setSelectedFilter] = useState<
    "all" | "featured" | "premium"
  >("all");
  const [activeCategories, setActiveCategories] = useState<string[]>([
    "Software",
    "Security",
  ]);

  const filterButtons = [
    { id: "all", label: "All" },
    { id: "featured", label: "Featured" },
    { id: "premium", label: "Premium" },
  ] as const;

  const categoryButtons = [
    { id: "software", label: "Software" },
    { id: "security", label: "Security" },
  ];

  const handleFilterClick = (filterId: "all" | "featured" | "premium") => {
    setSelectedFilter(filterId);
  };

  const handleCategoryToggle = (category: string) => {
    setActiveCategories((prev) =>
      prev.includes(category)
        ? prev.filter((c) => c !== category)
        : [...prev, category],
    );
  };

  const handleClearAll = () => {
    setActiveCategories([]);
  };

  return (
    <section
      className="absolute top-[238px] left-[calc(50.00%_-_667px)] w-[1318px] h-[470px]"
      aria-label="App search and filter section"
    >
      <div className="absolute w-[97.19%] h-[19.79%] top-[60.64%] left-0">
        <div className="absolute w-[99.84%] h-full top-0 left-0 bg-[#4a4a4a] rounded-[100px]" />

        <img
          className="absolute w-[3.54%] h-[48.39%] top-[25.81%] left-[2.68%]"
          alt=""
          src="/img/vector.svg"
          aria-hidden="true"
        />

        <label htmlFor="app-search" className="sr-only">
          Search keywords
        </label>
        <input
          id="app-search"
          type="search"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search keywords..."
          className="absolute w-[77.48%] h-full top-0 left-[8.82%] flex items-center justify-center [font-family:'Inter',Helvetica] font-normal text-white text-3xl tracking-[0] leading-[normal] bg-transparent border-none outline-none placeholder:text-white"
          aria-label="Search for apps by keywords"
        />

        <div
          className="absolute w-[462px] h-[59px] top-[17px] left-[788px]"
          role="group"
          aria-label="Filter apps by category"
        >
          {filterButtons.map((filter, index) => {
            const isActive = selectedFilter === filter.id;
            const leftPosition =
              index === 0 ? "0" : index === 1 ? "24.02%" : "63.10%";

            return (
              <button
                key={filter.id}
                onClick={() => handleFilterClick(filter.id)}
                className={`absolute w-[36.90%] h-full top-0 left-[${leftPosition}] flex rounded-[100px] border-[none] ${
                  isActive
                    ? ""
                    : "before:content-[''] before:absolute before:inset-0 before:p-0.5 before:rounded-[100px] before:[background:linear-gradient(180deg,rgba(224,255,4,1)_0%,rgba(79,255,227,1)_100%)] before:[-webkit-mask:linear-gradient(#fff_0_0)_content-box,linear-gradient(#fff_0_0)] before:[-webkit-mask-composite:xor] before:[mask-composite:exclude] before:z-[1] before:pointer-events-none"
                }`}
                style={{ left: leftPosition }}
                aria-pressed={isActive}
              >
                <div className="flex-1 w-[170.47px] flex">
                  <span
                    className={`flex items-center justify-center flex-1 w-[170.47px] ${
                      isActive
                        ? "bg-[linear-gradient(180deg,rgba(224,255,4,1)_0%,rgba(79,255,227,1)_100%)] text-neutral-800"
                        : "bg-[linear-gradient(180deg,rgba(224,255,4,1)_0%,rgba(79,255,227,1)_100%)] [-webkit-background-clip:text] bg-clip-text [-webkit-text-fill-color:transparent] [text-fill-color:transparent]"
                    } [font-family:'Roboto',Helvetica] font-normal text-[25px] text-center tracking-[0] leading-[normal]`}
                  >
                    {filter.label}
                  </span>
                </div>
              </button>
            );
          })}

          <div className="absolute w-[100px] h-[59px] top-0 left-0 flex">
            <div className="flex-1 w-[101.86px] relative">
              <div className="w-[98.04%] left-0 rounded-[100px] bg-[linear-gradient(180deg,rgba(224,255,4,1)_0%,rgba(79,255,227,1)_100%)] absolute h-full top-0" />

              <div className="absolute w-[98.04%] h-full top-0 left-0 flex items-center justify-center [font-family:'Roboto',Helvetica] font-normal text-neutral-800 text-[25px] text-center tracking-[0] leading-[normal]">
                All
              </div>
            </div>
          </div>
        </div>
      </div>

      <div
        className="absolute w-[550px] h-[59px] top-[411px] left-[25px] flex"
        role="group"
        aria-label="Active category filters"
      >
        <div className="flex-1 w-[552px] relative">
          {categoryButtons.map((category, index) => {
            const isActive = activeCategories.includes(category.label);
            const leftPosition = index === 0 ? "0" : "30.25%";
            const widthClass = index === 0 ? "w-[33.70%]" : "w-[36.23%]";

            return (
              <button
                key={category.id}
                onClick={() => handleCategoryToggle(category.label)}
                className={`absolute ${widthClass} h-full top-0`}
                style={{ left: leftPosition }}
                aria-pressed={isActive}
                aria-label={`${category.label} filter ${isActive ? "active" : "inactive"}`}
              >
                {index === 0 ? (
                  <>
                    <div className="w-[98.92%] left-0 bg-[#4a4a4a] rounded-[100px] absolute h-full top-0" />

                    <img
                      className="absolute w-[10.75%] h-[33.90%] top-[35.59%] left-[75.27%]"
                      alt=""
                      src="/img/vector-2.svg"
                      aria-hidden="true"
                    />

                    <span className="w-[53.76%] h-[49.15%] top-[28.81%] left-[9.68%] text-white text-[25px] absolute flex items-center justify-center [font-family:'Roboto',Helvetica] font-normal text-center tracking-[0] leading-[normal] whitespace-nowrap">
                      {category.label}
                    </span>
                  </>
                ) : (
                  <>
                    <div className="w-[84.50%] left-[15.50%] bg-[#4a4a4a] rounded-[100px] absolute h-full top-0" />

                    <div className="absolute w-[89.50%] h-full top-0 left-0">
                      <span className="absolute w-[50.28%] h-[49.15%] top-[25.42%] left-[29.61%] flex items-center justify-center [font-family:'Roboto',Helvetica] font-normal text-white text-[25px] text-center tracking-[0] leading-[normal] whitespace-nowrap">
                        {category.label}
                      </span>

                      <img
                        className="absolute w-[11.17%] h-[33.90%] top-[35.59%] left-[91.06%]"
                        alt=""
                        src="/img/vector-2.svg"
                        aria-hidden="true"
                      />
                    </div>
                  </>
                )}
              </button>
            );
          })}

          <button
            onClick={handleClearAll}
            className="absolute w-[38.77%] h-[91.53%] top-[6.78%] left-[60.87%] flex items-center justify-center bg-[linear-gradient(180deg,rgba(224,255,4,1)_0%,rgba(79,255,227,1)_100%)] [-webkit-background-clip:text] bg-clip-text [-webkit-text-fill-color:transparent] [text-fill-color:transparent] [font-family:'Roboto',Helvetica] font-normal text-transparent text-3xl text-center tracking-[0] leading-[normal]"
            aria-label="Clear all active filters"
          >
            Clear All
          </button>
        </div>
      </div>
    </section>
  );
};
