export { StyleOutlined3 } from "./StyleOutlined3";
