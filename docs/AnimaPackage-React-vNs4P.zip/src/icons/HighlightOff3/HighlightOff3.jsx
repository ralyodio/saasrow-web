/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const HighlightOff3 = ({ className }) => {
  return (
    <svg
      className={`highlight-off-3 ${className}`}
      fill="none"
      height="45"
      viewBox="0 0 45 45"
      width="45"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M26.8258 14.7091L22.0637 19.4712L17.3016 14.7091L14.7092 17.3016L19.4712 22.0637L14.7092 26.8258L17.3016 29.4183L22.0637 24.6562L26.8258 29.4183L29.4183 26.8258L24.6562 22.0637L29.4183 17.3016L26.8258 14.7091ZM22.0637 3.67725C11.896 3.67725 3.67728 11.896 3.67728 22.0637C3.67728 32.2314 11.896 40.4502 22.0637 40.4502C32.2314 40.4502 40.4502 32.2314 40.4502 22.0637C40.4502 11.896 32.2314 3.67725 22.0637 3.67725ZM22.0637 36.7729C13.9553 36.7729 7.35457 30.1721 7.35457 22.0637C7.35457 13.9553 13.9553 7.35454 22.0637 7.35454C30.1722 7.35454 36.7729 13.9553 36.7729 22.0637C36.7729 30.1721 30.1722 36.7729 22.0637 36.7729Z"
        fill="url(#paint0_linear_2029_7469)"
      />

      <defs className="defs">
        <linearGradient
          className="linear-gradient"
          gradientUnits="userSpaceOnUse"
          id="paint0_linear_2029_7469"
          x1="22.0637"
          x2="22.0637"
          y1="3.67725"
          y2="40.4502"
        >
          <stop className="stop" stopColor="#E0FF04" />

          <stop className="stop" offset="1" stopColor="#4FFFE3" />
        </linearGradient>
      </defs>
    </svg>
  );
};
