export { Property1Close } from "./Property1Close";
