/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const StyleRound3 = ({ className }) => {
  return (
    <svg
      className={`style-round-3 ${className}`}
      fill="none"
      height="24"
      viewBox="0 0 24 24"
      width="24"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M19 11C19 7.13 15.87 4 12 4C8.78 4 6.07 6.18 5.26 9.15C2.82 9.71 1 11.89 1 14.5C1 17.54 3.46 20 6.5 20C8.26 20 16.75 20 18.5 20C20.99 19.99 23 17.97 23 15.48C23 13.15 21.25 11.26 19 11ZM13 13V15C13 15.55 12.55 16 12 16C11.45 16 11 15.55 11 15V13H9.21C8.76 13 8.54 12.46 8.86 12.15L11.65 9.36C11.85 9.16 12.16 9.16 12.36 9.36L15.15 12.15C15.46 12.46 15.24 13 14.8 13H13Z"
        fill="black"
      />
    </svg>
  );
};
