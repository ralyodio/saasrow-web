/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Backup2 = ({ className }) => {
  return (
    <svg
      className={`backup-2 ${className}`}
      fill="none"
      height="67"
      viewBox="0 0 67 67"
      width="67"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g className="g" clipPath="url(#clip0_6003_220)">
        <path
          className="path"
          d="M53.3667 27.69C51.4913 18.175 43.1346 11.0319 33.0956 11.0319C25.1251 11.0319 18.2026 15.5549 14.7551 22.1741C6.45364 23.0566 -7.62939e-06 30.0894 -7.62939e-06 38.6115C-7.62939e-06 47.7404 7.41893 55.1594 16.5478 55.1594H52.4014C60.0134 55.1594 66.1912 48.9815 66.1912 41.3695C66.1912 34.0885 60.5374 28.1864 53.3667 27.69ZM52.4014 49.6434H16.5478C10.4527 49.6434 5.51593 44.7067 5.51593 38.6115C5.51593 32.9577 9.73562 28.2416 15.3343 27.6624L18.2853 27.359L19.6643 24.739C22.2844 19.6919 27.4142 16.5478 33.0956 16.5478C40.3215 16.5478 46.5545 21.6776 47.9611 28.7656L48.7885 32.9025L53.0081 33.2059C57.3106 33.4817 60.6753 37.0947 60.6753 41.3695C60.6753 45.9202 56.952 49.6434 52.4014 49.6434ZM22.0637 35.8536H29.0966V44.1275H37.0947V35.8536H44.1275L33.0956 24.8217L22.0637 35.8536Z"
          fill="url(#paint0_linear_6003_220)"
        />
      </g>

      <defs className="defs">
        <linearGradient
          className="linear-gradient"
          gradientUnits="userSpaceOnUse"
          id="paint0_linear_6003_220"
          x1="33.0956"
          x2="33.0956"
          y1="11.0319"
          y2="55.1594"
        >
          <stop className="stop" stopColor="#E0FF04" />

          <stop className="stop" offset="1" stopColor="#4FFFE3" />
        </linearGradient>

        <clipPath className="clip-path" id="clip0_6003_220">
          <rect
            className="rect"
            fill="white"
            height="66.1912"
            width="66.1912"
          />
        </clipPath>
      </defs>
    </svg>
  );
};
