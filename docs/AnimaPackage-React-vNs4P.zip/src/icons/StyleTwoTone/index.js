export { StyleTwoTone } from "./StyleTwoTone";
