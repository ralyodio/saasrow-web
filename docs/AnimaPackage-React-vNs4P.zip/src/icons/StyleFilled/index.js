export { StyleFilled } from "./StyleFilled";
