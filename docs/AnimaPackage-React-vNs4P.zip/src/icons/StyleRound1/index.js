export { StyleRound1 } from "./StyleRound1";
