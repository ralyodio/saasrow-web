/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";

export const VariantSharp = ({ color = "#373737", className }) => {
  return (
    <svg
      className={`variant-sharp ${className}`}
      fill="none"
      height="24"
      viewBox="0 0 24 24"
      width="24"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        clipRule="evenodd"
        d="M20.9557 5.90223L9.05079 19.5079L3.04214 13.4992L4.50055 12.0408L8.95032 16.4906L19.4035 4.54407L20.9557 5.90223Z"
        fill={color}
        fillRule="evenodd"
      />
    </svg>
  );
};

VariantSharp.propTypes = {
  color: PropTypes.string,
};
