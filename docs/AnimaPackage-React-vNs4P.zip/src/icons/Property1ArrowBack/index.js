export { Property1ArrowBack } from "./Property1ArrowBack";
