export { StyleTwoTone6 } from "./StyleTwoTone6";
