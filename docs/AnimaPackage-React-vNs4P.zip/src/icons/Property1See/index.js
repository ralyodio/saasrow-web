export { Property1See } from "./Property1See";
