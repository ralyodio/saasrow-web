export { StyleFilled4 } from "./StyleFilled4";
