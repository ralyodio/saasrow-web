export { StyleFilled5 } from "./StyleFilled5";
