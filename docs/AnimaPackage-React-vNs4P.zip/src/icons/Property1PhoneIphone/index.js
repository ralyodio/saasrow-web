export { Property1PhoneIphone } from "./Property1PhoneIphone";
