export { StyleTwoTone4 } from "./StyleTwoTone4";
