export { StyleFilled3 } from "./StyleFilled3";
