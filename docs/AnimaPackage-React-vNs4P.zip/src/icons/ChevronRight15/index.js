export { ChevronRight15 } from "./ChevronRight15";
