export { Property1FavoriteBorder } from "./Property1FavoriteBorder";
