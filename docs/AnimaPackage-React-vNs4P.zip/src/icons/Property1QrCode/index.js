export { Property1QrCode } from "./Property1QrCode";
