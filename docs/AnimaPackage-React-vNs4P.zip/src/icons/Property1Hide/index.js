export { Property1Hide } from "./Property1Hide";
