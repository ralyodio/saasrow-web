export { StyleFilled2 } from "./StyleFilled2";
