export { Property1ShoppingBag } from "./Property1ShoppingBag";
