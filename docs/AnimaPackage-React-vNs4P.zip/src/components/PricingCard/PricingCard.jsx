/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { Sparkles } from "../../icons/Sparkles";
import { Button } from "../Button";
import { FeatureRow } from "../FeatureRow";
import "./style.css";

export const PricingCard = ({
  showFeatureList = true,
  kind,
  version,
  className,
  hasCardContent = true,
}) => {
  return (
    <div className={`pricing-card ${version} ${kind} ${className}`}>
      {kind === "default" && (
        <>
          <>
            {hasCardContent && (
              <div className="card-content">
                {version === "ver-1" && (
                  <div className="pricing-headear">
                    <div className="frame">
                      <div className="text-wrapper-8">Free</div>

                      {showFeatureList && (
                        <div className="text-wrapper-9">
                          Best for personal use
                        </div>
                      )}
                    </div>

                    <div className="frame-2">
                      <div className="text-wrapper-10">$0</div>

                      <div className="text-wrapper-11">/month</div>
                    </div>
                  </div>
                )}

                {version === "ver-2" && (
                  <>
                    <div className="pricing-headear-2">
                      <div className="frame">
                        <div className="text-wrapper-8">Free</div>

                        {showFeatureList && (
                          <div className="text-wrapper-9">
                            Best for personal use
                          </div>
                        )}
                      </div>

                      <div className="frame-2">
                        <div className="text-wrapper-10">$0</div>

                        <div className="text-wrapper-11">/month</div>
                      </div>
                    </div>

                    <>
                      {showFeatureList && (
                        <div className="pricing-features">
                          <div className="text-wrapper-12">What you get</div>

                          <FeatureRow
                            className="instance-node"
                            divClassName="feature-row-instance"
                          />
                          <FeatureRow
                            className="instance-node"
                            divClassName="feature-row-instance"
                          />
                          <FeatureRow
                            className="instance-node"
                            divClassName="feature-row-instance"
                          />
                          <FeatureRow
                            className="instance-node"
                            divClassName="feature-row-instance"
                          />
                          <FeatureRow
                            className="instance-node"
                            divClassName="feature-row-instance"
                          />
                        </div>
                      )}
                    </>
                  </>
                )}

                <Button className="instance-node" property1="default" />

                {version === "ver-1" && (
                  <>
                    <>
                      {showFeatureList && (
                        <div className="pricing-features-2">
                          <div className="text-wrapper-12">What you get</div>

                          <FeatureRow
                            className="instance-node"
                            divClassName="feature-row-instance"
                          />
                          <FeatureRow
                            className="instance-node"
                            divClassName="feature-row-instance"
                          />
                          <FeatureRow
                            className="instance-node"
                            divClassName="feature-row-instance"
                          />
                          <FeatureRow
                            className="instance-node"
                            divClassName="feature-row-instance"
                          />
                          <FeatureRow
                            className="instance-node"
                            divClassName="feature-row-instance"
                          />
                        </div>
                      )}
                    </>
                  </>
                )}
              </div>
            )}
          </>
        </>
      )}

      {kind === "popular" && (
        <>
          <div className="card-content-2">
            {version === "ver-2" && (
              <>
                <div className="pricing-headear-3">
                  <div className="frame-3">
                    <div className="frame-4">
                      <div className="text-wrapper-13">Free</div>
                    </div>

                    {showFeatureList && (
                      <div className="text-wrapper-9">
                        Best for personal use
                      </div>
                    )}
                  </div>

                  <div className="frame-2">
                    <div className="text-wrapper-10">$0</div>

                    <div className="text-wrapper-11">/month</div>
                  </div>
                </div>

                <>
                  {showFeatureList && (
                    <div className="pricing-features">
                      <div className="text-wrapper-12">What you get</div>

                      <FeatureRow
                        className="instance-node"
                        divClassName="feature-row-instance"
                      />
                      <FeatureRow
                        className="instance-node"
                        divClassName="feature-row-instance"
                      />
                      <FeatureRow
                        className="instance-node"
                        divClassName="feature-row-instance"
                      />
                      <FeatureRow
                        className="instance-node"
                        divClassName="feature-row-instance"
                      />
                      <FeatureRow
                        className="instance-node"
                        divClassName="feature-row-instance"
                      />
                    </div>
                  )}
                </>

                <Button className="instance-node" property1="default" />
              </>
            )}

            {version === "ver-1" && (
              <>
                <div className="text-wrapper-14">Most Popular</div>

                <Sparkles className="sparkles-instance" />
              </>
            )}
          </div>

          <div className="puplar">
            {version === "ver-2" && (
              <div className="text-wrapper-15">Most Popular</div>
            )}

            {version === "ver-1" && (
              <>
                <div className="pricing-headear">
                  <div className="frame">
                    <div className="text-wrapper-8">Free</div>

                    {showFeatureList && (
                      <div className="text-wrapper-9">
                        Best for personal use
                      </div>
                    )}
                  </div>

                  <div className="frame-2">
                    <div className="text-wrapper-10">$0</div>

                    <div className="text-wrapper-11">/month</div>
                  </div>
                </div>

                <Button className="instance-node" property1="default" />

                <>
                  {showFeatureList && (
                    <div className="pricing-features-2">
                      <div className="text-wrapper-12">What you get</div>

                      <FeatureRow
                        className="instance-node"
                        divClassName="feature-row-instance"
                      />
                      <FeatureRow
                        className="instance-node"
                        divClassName="feature-row-instance"
                      />
                      <FeatureRow
                        className="instance-node"
                        divClassName="feature-row-instance"
                      />
                      <FeatureRow
                        className="instance-node"
                        divClassName="feature-row-instance"
                      />
                      <FeatureRow
                        className="instance-node"
                        divClassName="feature-row-instance"
                      />
                    </div>
                  )}
                </>
              </>
            )}
          </div>
        </>
      )}
    </div>
  );
};

PricingCard.propTypes = {
  showFeatureList: PropTypes.bool,
  kind: PropTypes.oneOf(["popular", "default"]),
  version: PropTypes.oneOf(["ver-2", "ver-1"]),
  hasCardContent: PropTypes.bool,
};
