import { PricingCard } from ".";

export default {
  title: "Components/PricingCard",
  component: PricingCard,

  argTypes: {
    kind: {
      options: ["popular", "default"],
      control: { type: "select" },
    },
    version: {
      options: ["ver-2", "ver-1"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    showFeatureList: true,
    kind: "popular",
    version: "ver-2",
    className: {},
    hasCardContent: true,
  },
};
