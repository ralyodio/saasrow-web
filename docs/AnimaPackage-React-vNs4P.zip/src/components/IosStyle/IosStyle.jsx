/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const IosStyle = ({
  size,
  active,
  disabled,
  className,
  knob = "/img/knob-9.svg",
  knobClassName,
}) => {
  return (
    <div
      className={`ios-style size-2-${size} disabled-${disabled} ${active} ${className}`}
    >
      <img
        className={`knob ${knobClassName}`}
        alt="Knob"
        src={
          active === "on" && disabled && size === "medium"
            ? "/img/knob-8.svg"
            : size === "small" && !disabled && active === "on"
              ? knob
              : size === "small" && disabled && active === "on"
                ? "/img/knob-10.svg"
                : active === "off" && !disabled && size === "medium"
                  ? "/img/knob-11.svg"
                  : active === "off" && size === "medium" && disabled
                    ? "/img/knob-12.svg"
                    : active === "off" && size === "small" && !disabled
                      ? "/img/knob-13.svg"
                      : active === "off" && size === "small" && disabled
                        ? "/img/knob-14.svg"
                        : "/img/knob-7.svg"
        }
      />
    </div>
  );
};

IosStyle.propTypes = {
  size: PropTypes.oneOf(["medium", "small"]),
  active: PropTypes.oneOf(["off", "on"]),
  disabled: PropTypes.bool,
  knob: PropTypes.string,
};
