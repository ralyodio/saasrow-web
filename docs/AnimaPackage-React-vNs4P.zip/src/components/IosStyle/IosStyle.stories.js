import { IosStyle } from ".";

export default {
  title: "Components/IosStyle",
  component: IosStyle,

  argTypes: {
    size: {
      options: ["medium", "small"],
      control: { type: "select" },
    },
    active: {
      options: ["off", "on"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    size: "medium",
    active: "off",
    disabled: true,
    className: {},
    knob: "/img/knob-9.svg",
    knobClassName: {},
  },
};
