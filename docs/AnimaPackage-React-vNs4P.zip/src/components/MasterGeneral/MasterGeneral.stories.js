import { MasterGeneral } from ".";

export default {
  title: "Components/MasterGeneral",
  component: MasterGeneral,

  argTypes: {
    type: {
      options: ["caption", "title", "sub-title"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    toggle: true,
    divider: true,
    desc: true,
    badge: true,
    link: true,
    icon1: true,
    right: true,
    icon2: true,
    value: true,
    dropdown: true,
    title: "Title Section",
    type: "caption",
    className: {},
    hasDiv: true,
    iosStyleKnob: "/img/knob-4.svg",
    divClassName: {},
    divClassNameOverride: {},
  },
};
