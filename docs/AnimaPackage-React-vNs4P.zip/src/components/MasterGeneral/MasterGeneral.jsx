/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { ExpandMore } from "../../icons/ExpandMore";
import { StyleRound5 } from "../../icons/StyleRound5";
import { Divider } from "../Divider";
import { IosStyle } from "../IosStyle";
import { SharpCorner } from "../SharpCorner";
import "./style.css";

export const MasterGeneral = ({
  toggle = true,
  divider = true,
  desc = true,
  badge = true,
  link = true,
  icon1 = true,
  right = true,
  icon2 = true,
  value = true,
  dropdown = true,
  title = "Title Section",
  type,
  className,
  hasDiv = true,
  iosStyleKnob = "/img/knob-4.svg",
  divClassName,
  divClassNameOverride,
}) => {
  return (
    <div className={`master-general ${className}`}>
      <div className="wrapper">
        <div className="left">
          {hasDiv && (
            <div className={`title-section type-${type}`}>
              {["sub-title", "title"].includes(type) && <>Title Section</>}

              {type === "caption" && <>{title}</>}
            </div>
          )}

          {desc && (
            <p className={`desc type-0-${type}`}>
              The quick brown fox jumps over the lazy dog
            </p>
          )}
        </div>

        {right && (
          <div className="right">
            {link && (
              <div className={`text-wrapper-16 type-1-${type} ${divClassName}`}>
                Text link
              </div>
            )}

            {value && (
              <div
                className={`text-wrapper-17 type-2-${type} ${divClassNameOverride}`}
              >
                Value
              </div>
            )}

            {icon2 && (
              <StyleRound5
                className={`${type === "caption" ? "class" : "class-2"}`}
                color="#0B0B0B"
              />
            )}

            {icon1 && (
              <ExpandMore
                className={`${type === "caption" ? "class" : "class-2"}`}
                color="#0B0B0B"
              />
            )}

            {badge && (
              <SharpCorner
                className="sharp-corner-instance"
                color="primary"
                filled={false}
                size="tiny"
                style="text"
              />
            )}

            {toggle && (
              <IosStyle
                active="on"
                className="ios-style-instance"
                disabled={false}
                knob={iosStyleKnob}
                knobClassName={`${type === "caption" && "class-3"}`}
                size="small"
              />
            )}
          </div>
        )}
      </div>

      {divider && (
        <Divider
          borderWeight="one-px"
          className="divider-instance"
          size="full"
          variants="solid"
        />
      )}
    </div>
  );
};

MasterGeneral.propTypes = {
  toggle: PropTypes.bool,
  divider: PropTypes.bool,
  desc: PropTypes.bool,
  badge: PropTypes.bool,
  link: PropTypes.bool,
  icon1: PropTypes.bool,
  right: PropTypes.bool,
  icon2: PropTypes.bool,
  value: PropTypes.bool,
  dropdown: PropTypes.bool,
  title: PropTypes.string,
  type: PropTypes.oneOf(["caption", "title", "sub-title"]),
  hasDiv: PropTypes.bool,
  iosStyleKnob: PropTypes.string,
};
