export { MasterGeneral } from "./MasterGeneral";
