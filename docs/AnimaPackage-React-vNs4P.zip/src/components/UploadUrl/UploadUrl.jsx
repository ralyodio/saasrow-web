/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { DeleteOutline } from "../../icons/DeleteOutline";
import { PauseCircle } from "../../icons/PauseCircle";
import { Repeat } from "../../icons/Repeat";
import { StyleTwoTone } from "../../icons/StyleTwoTone";
import { Outline } from "../Outline";
import "./style.css";

export const UploadUrl = ({
  states,
  className,
  rowClassName,
  outlineMasterOutlineDivClassName,
  outlineMasterOutlineSizeLargeClassName,
}) => {
  return (
    <div className={`upload-URL states-5-${states} ${className}`}>
      {["active", "disabled", "uploading-alt", "uploading"].includes(
        states,
      ) && (
        <>
          <div className={`row ${rowClassName}`}>
            {states === "uploading" && (
              <img
                className="rectangle"
                alt="Rectangle"
                src="/img/rectangle-1.png"
              />
            )}

            {["uploading-alt", "uploading"].includes(states) && (
              <>
                <div className="text-4">
                  <div className="div-2">
                    {states === "uploading" && <>filename.jpg</>}

                    {states === "uploading-alt" && <>Uploading...</>}
                  </div>

                  <div className="element">
                    {states === "uploading" && <>500kb</>}

                    {states === "uploading-alt" && (
                      <>65%&nbsp;&nbsp;• 30 seconds remaining</>
                    )}
                  </div>
                </div>

                <div className="action">
                  {states === "uploading-alt" && (
                    <PauseCircle className="instance-node-2" />
                  )}

                  <StyleTwoTone
                    className="instance-node-2"
                    color={states === "uploading" ? "#858585" : "#FF3636"}
                  />
                </div>
              </>
            )}

            {["active", "disabled"].includes(states) && (
              <>https://sharefile.xyz/file.jpg</>
            )}
          </div>

          <div className="progress-linear">
            {states === "uploading" && (
              <>
                <div className="master-linear-wrapper">
                  <div className="master-linear-2" />
                </div>

                <div className="label">60%</div>
              </>
            )}

            {["active", "disabled", "uploading-alt"].includes(states) && (
              <div className="master-button">
                {["active", "disabled"].includes(states) && (
                  <div className="button-3">Upload</div>
                )}
              </div>
            )}
          </div>
        </>
      )}

      {["done", "failed"].includes(states) && (
        <div className="frame-7">
          <img
            className="rectangle"
            alt="Rectangle"
            src={
              states === "done"
                ? "/img/rectangle-1-1.png"
                : "/img/rectangle-1.png"
            }
          />

          <div className="text-4">
            <div className="div-2">filename.jpg</div>

            <div className="upload-failed">
              {states === "failed" && <>Upload failed</>}

              {states === "done" && <>500kb</>}
            </div>
          </div>

          <div className="action">
            {states === "failed" && (
              <>
                <DeleteOutline className="instance-node-2" />
                <Repeat className="instance-node-2" />
              </>
            )}

            {states === "done" && (
              <StyleTwoTone className="instance-node-2" color="#858585" />
            )}
          </div>
        </div>
      )}

      {states === "default" && (
        <>
          <div className={`URL ${rowClassName}`}>Add file URL</div>

          <Outline
            className="outline-5"
            masterOutlineDivClassName={outlineMasterOutlineDivClassName}
            masterOutlineSizeLargeClassName={
              outlineMasterOutlineSizeLargeClassName
            }
            masterOutlineText="Upload"
            sizes="small"
            states="default"
            style="standard"
            type="neutral"
          />
        </>
      )}
    </div>
  );
};

UploadUrl.propTypes = {
  states: PropTypes.oneOf([
    "active",
    "default",
    "failed",
    "disabled",
    "done",
    "uploading-alt",
    "uploading",
  ]),
};
