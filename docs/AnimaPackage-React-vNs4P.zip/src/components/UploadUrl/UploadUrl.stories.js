import { UploadUrl } from ".";

export default {
  title: "Components/UploadUrl",
  component: UploadUrl,

  argTypes: {
    states: {
      options: [
        "active",
        "default",
        "failed",
        "disabled",
        "done",
        "uploading-alt",
        "uploading",
      ],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    states: "active",
    className: {},
    rowClassName: {},
    outlineMasterOutlineDivClassName: {},
    outlineMasterOutlineSizeLargeClassName: {},
  },
};
