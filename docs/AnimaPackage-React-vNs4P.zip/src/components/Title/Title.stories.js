import { Title } from ".";

export default {
  title: "Components/Title",
  component: Title,

  argTypes: {
    type: {
      options: [
        "value-trailing",
        "value",
        "default",
        "link-badge",
        "multi-trailing",
        "single-trailing",
        "link",
        "badge",
        "toggle",
      ],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    type: "value-trailing",
    desc: true,
    div: true,
    className: {},
    masterGeneralHasDiv: true,
    masterGeneralIcon1: true,
    masterGeneralDesc: true,
  },
};
