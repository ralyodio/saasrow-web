/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { MasterGeneral } from "../MasterGeneral";
import "./style.css";

export const Title = ({
  type,
  desc,
  div,
  className,
  masterGeneralHasDiv,
  masterGeneralIcon1,
  masterGeneralDesc,
}) => {
  return (
    <div className={`title type-${type} div-${div} desc-${desc} ${className}`}>
      <MasterGeneral
        badge={
          [
            "link",
            "multi-trailing",
            "single-trailing",
            "toggle",
            "value-trailing",
            "value",
          ].includes(type)
            ? false
            : undefined
        }
        className="master-general-instance"
        desc={masterGeneralDesc}
        divClassName={`${["link-badge", "link"].includes(type) && "class-4"}`}
        divClassNameOverride={`${type === "value" && "class-4"}`}
        divider={!div ? false : undefined}
        hasDiv={masterGeneralHasDiv}
        icon1={masterGeneralIcon1}
        icon2={
          type === "badge" ||
          type === "link-badge" ||
          type === "link" ||
          type === "single-trailing" ||
          type === "toggle" ||
          type === "value-trailing" ||
          type === "value"
            ? false
            : undefined
        }
        iosStyleKnob={
          !div && type === "toggle" && !desc
            ? "/img/knob.svg"
            : type === "toggle" && div && !desc
              ? "/img/knob-1.svg"
              : !div && type === "toggle" && desc
                ? "/img/knob-2.svg"
                : type === "toggle" && div && desc
                  ? "/img/knob-3.svg"
                  : undefined
        }
        link={
          [
            "badge",
            "multi-trailing",
            "single-trailing",
            "toggle",
            "value-trailing",
            "value",
          ].includes(type)
            ? false
            : undefined
        }
        right={type === "default" ? false : undefined}
        toggle={
          type === "badge" ||
          type === "link-badge" ||
          type === "link" ||
          type === "multi-trailing" ||
          type === "single-trailing" ||
          type === "value-trailing" ||
          type === "value"
            ? false
            : undefined
        }
        type="title"
        value={
          [
            "badge",
            "link-badge",
            "link",
            "multi-trailing",
            "single-trailing",
            "toggle",
          ].includes(type)
            ? false
            : undefined
        }
      />
    </div>
  );
};

Title.propTypes = {
  type: PropTypes.oneOf([
    "value-trailing",
    "value",
    "default",
    "link-badge",
    "multi-trailing",
    "single-trailing",
    "link",
    "badge",
    "toggle",
  ]),
  desc: PropTypes.bool,
  div: PropTypes.bool,
  masterGeneralHasDiv: PropTypes.bool,
  masterGeneralIcon1: PropTypes.bool,
  masterGeneralDesc: PropTypes.bool,
};
