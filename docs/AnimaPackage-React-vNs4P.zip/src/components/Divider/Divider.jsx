/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const Divider = ({
  variants,
  size,
  borderWeight,
  className,
  lineClassName,
  divClassName,
  text = "Text",
  lineClassNameOverride,
}) => {
  return (
    <div className={`divider ${borderWeight} ${variants} ${className}`}>
      {borderWeight === "w-text" && (
        <>
          <div className={`line-2 ${lineClassName}`} />

          <div className={`text-3 ${divClassName}`}>{text}</div>

          <div className={`line-3 ${lineClassNameOverride}`} />
        </>
      )}
    </div>
  );
};

Divider.propTypes = {
  variants: PropTypes.oneOf(["solid", "dash"]),
  size: PropTypes.oneOf(["full"]),
  borderWeight: PropTypes.oneOf(["one-px", "three-px", "w-text", "two-px"]),
  text: PropTypes.string,
};
