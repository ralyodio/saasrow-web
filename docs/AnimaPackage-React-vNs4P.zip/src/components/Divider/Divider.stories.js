import { Divider } from ".";

export default {
  title: "Components/Divider",
  component: Divider,

  argTypes: {
    variants: {
      options: ["solid", "dash"],
      control: { type: "select" },
    },
    size: {
      options: ["full"],
      control: { type: "select" },
    },
    borderWeight: {
      options: ["one-px", "three-px", "w-text", "two-px"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    variants: "solid",
    size: "full",
    borderWeight: "one-px",
    className: {},
    lineClassName: {},
    divClassName: {},
    text: "Text",
    lineClassNameOverride: {},
  },
};
