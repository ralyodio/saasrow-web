/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const DivWrapper = ({ className, line = "/img/line-2.svg" }) => {
  return (
    <div className={`div-wrapper ${className}`}>
      <div className="group-4">
        <p className="element-torahweb-all">
          © 2019 SaaSRow. All rights reserved.
        </p>

        <div className="terms-of-service-pri">
          Terms of
          Service&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Privacy
          Policy
        </div>

        <img className="line" alt="Line" src={line} />

        <div className="links">
          <div className="text-wrapper-5">Discover</div>

          <div className="text-wrapper-6">About us</div>

          <div className="text-wrapper-7">Explore</div>

          <div className="books">News</div>
        </div>

        <img className="social" alt="Social" src="/img/social.png" />
      </div>

      <img
        className="img"
        alt="Wiresniff logo"
        src="/img/wiresniff-logo-1.png"
      />
    </div>
  );
};

DivWrapper.propTypes = {
  line: PropTypes.string,
};
