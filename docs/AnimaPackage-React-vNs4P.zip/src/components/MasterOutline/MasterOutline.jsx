/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { ChevronRight15 } from "../../icons/ChevronRight15";
import { Info61 } from "../../icons/Info61";
import "./style.css";

export const MasterOutline = ({
  leading = true,
  trailing = true,
  size,
  className,
  divClassName,
  text = "Button",
  info61Color = "#1849D6",
  chevronRight15Color = "#1849D6",
}) => {
  return (
    <div className={`master-outline ${size} ${className}`}>
      {leading && (
        <Info61
          className={`${size === "large" ? "class-5" : (size === "medium") ? "class-6" : "class-7"}`}
          color={info61Color}
        />
      )}

      <div className={`button-2 ${divClassName}`}>{text}</div>

      {trailing && (
        <ChevronRight15
          className={`${size === "large" ? "class-5" : (size === "medium") ? "class-6" : "class-7"}`}
          color={chevronRight15Color}
        />
      )}
    </div>
  );
};

MasterOutline.propTypes = {
  leading: PropTypes.bool,
  trailing: PropTypes.bool,
  size: PropTypes.oneOf(["large", "tiny", "medium", "small"]),
  text: PropTypes.string,
  info61Color: PropTypes.string,
  chevronRight15Color: PropTypes.string,
};
