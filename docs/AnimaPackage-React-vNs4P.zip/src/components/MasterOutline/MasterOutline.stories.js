import { MasterOutline } from ".";

export default {
  title: "Components/MasterOutline",
  component: MasterOutline,

  argTypes: {
    size: {
      options: ["large", "tiny", "medium", "small"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    leading: true,
    trailing: true,
    size: "large",
    className: {},
    divClassName: {},
    text: "Button",
    info61Color: "#1849D6",
    chevronRight15Color: "#1849D6",
  },
};
