/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { VariantSharp } from "../../icons/VariantSharp";
import "./style.css";

export const FeatureRow = ({
  showInformationCircle = false,
  className,
  divClassName,
}) => {
  return (
    <div className={`feature-row ${className}`}>
      <VariantSharp className="checkmark" color="#1D4ED8" />
      <div className={`text-wrapper-22 ${divClassName}`}>What you get</div>
    </div>
  );
};

FeatureRow.propTypes = {
  showInformationCircle: PropTypes.bool,
};
