import { FeatureRow } from ".";

export default {
  title: "Components/FeatureRow",
  component: FeatureRow,
};

export const Default = {
  args: {
    showInformationCircle: false,
    className: {},
    divClassName: {},
  },
};
