/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { Info61 } from "../../icons/Info61";
import { MasterBadges } from "../MasterBadges";
import "./style.css";

export const SharpCorner = ({ size, color, style, filled, className }) => {
  return (
    <div className={`sharp-corner ${className}`}>
      <MasterBadges
        className={`${!filled && color === "secondary" ? "class-8" : (filled && color === "primary") ? "class-9" : filled && color === "secondary" ? "class-10" : !filled && color === "orange" ? "class-11" : !filled && color === "green" ? "class-12" : !filled && color === "red" ? "class-13" : !filled && color === "grey" ? "class-14" : color === "blue" && !filled ? "class-15" : filled && color === "orange" ? "class-16" : filled && color === "green" ? "class-17" : filled && color === "red" ? "class-18" : filled && color === "grey" ? "class-19" : color === "blue" && filled ? "class-20" : "class-21"}`}
        icon={
          style === "leading" ? (
            <Info61
              className={`${size === "large" && "class-30"} ${size === "small" && "class-31"} ${size === "tiny" && "class-32"}`}
              color={
                !filled && color === "primary"
                  ? "#1849D6"
                  : !filled && color === "secondary"
                    ? "#0EACB4"
                    : (color === "blue" && filled) ||
                        (color === "green" && filled) ||
                        (color === "orange" && filled) ||
                        (color === "primary" && filled) ||
                        (color === "red" && filled) ||
                        (color === "secondary" && filled)
                      ? "white"
                      : !filled && color === "orange"
                        ? "#FFA24D"
                        : !filled && color === "green"
                          ? "#1FBE42"
                          : !filled && color === "red"
                            ? "#FF3636"
                            : color === "grey"
                              ? "#545454"
                              : color === "blue" && !filled
                                ? "#1745C1"
                                : undefined
              }
            />
          ) : undefined
        }
        labelTextClassName={`${!filled && color === "primary" && "class-22"} ${!filled && color === "secondary" && "class-23"} ${filled && ["blue", "primary"].includes(color) && "class-24"} ${!filled && color === "orange" && "class-25"} ${!filled && color === "green" && "class-26"} ${!filled && color === "red" && "class-27"} ${color === "grey" && "class-28"} ${color === "blue" && !filled && "class-29"}`}
        leading={["text", "trailing"].includes(style) ? false : undefined}
        override={
          style === "trailing" ? (
            <Info61
              className={`${size === "large" && "class-30"} ${size === "small" && "class-31"} ${size === "tiny" && "class-32"}`}
              color={
                !filled && color === "primary"
                  ? "#1849D6"
                  : !filled && color === "secondary"
                    ? "#0EACB4"
                    : (color === "blue" && filled) ||
                        (color === "green" && filled) ||
                        (color === "orange" && filled) ||
                        (color === "primary" && filled) ||
                        (color === "red" && filled) ||
                        (color === "secondary" && filled)
                      ? "white"
                      : !filled && color === "orange"
                        ? "#FFA24D"
                        : !filled && color === "green"
                          ? "#1FBE42"
                          : !filled && color === "red"
                            ? "#FF3636"
                            : color === "grey"
                              ? "#545454"
                              : color === "blue" && !filled
                                ? "#1745C1"
                                : undefined
              }
            />
          ) : undefined
        }
        size={size === "small" ? "small" : size === "tiny" ? "tiny" : "large"}
        text="Badges"
        trailing={["leading", "text"].includes(style) ? false : undefined}
      />
    </div>
  );
};

SharpCorner.propTypes = {
  size: PropTypes.oneOf(["large", "tiny", "small"]),
  color: PropTypes.oneOf([
    "secondary",
    "primary",
    "grey",
    "blue",
    "green",
    "orange",
    "red",
  ]),
  style: PropTypes.oneOf(["text", "trailing", "leading"]),
  filled: PropTypes.bool,
};
