import { Outline } from ".";

export default {
  title: "Components/Outline",
  component: Outline,

  argTypes: {
    style: {
      options: ["trailing", "standard", "leading"],
      control: { type: "select" },
    },
    type: {
      options: ["primary", "neutral", "secondary"],
      control: { type: "select" },
    },
    sizes: {
      options: ["large", "tiny", "medium", "small"],
      control: { type: "select" },
    },
    states: {
      options: ["default", "selected", "focus", "hover", "disabled"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    style: "trailing",
    type: "primary",
    sizes: "large",
    states: "default",
    className: {},
    masterOutlineSizeLargeClassName: {},
    masterOutlineDivClassName: {},
    masterOutlineText: "Button",
  },
};
