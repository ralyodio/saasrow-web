/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { MasterOutline } from "../MasterOutline";
import "./style.css";

export const Outline = ({
  style,
  type,
  sizes,
  states,
  className,
  masterOutlineSizeLargeClassName,
  masterOutlineDivClassName,
  masterOutlineText = "Button",
}) => {
  return (
    <div className={`outline ${className}`}>
      <MasterOutline
        chevronRight15Color={
          (states === "default" &&
            style === "trailing" &&
            type === "secondary") ||
          (states === "focus" &&
            style === "trailing" &&
            type === "secondary") ||
          (states === "hover" && style === "trailing" && type === "secondary")
            ? "#0EACB4"
            : (states === "focus" &&
                  style === "trailing" &&
                  type === "neutral") ||
                (states === "hover" &&
                  style === "trailing" &&
                  type === "neutral") ||
                (states === "selected" &&
                  style === "trailing" &&
                  type === "neutral")
              ? "#0B0B0B"
              : type === "primary" &&
                  style === "trailing" &&
                  states === "selected"
                ? "#0C246B"
                : type === "secondary" &&
                    style === "trailing" &&
                    states === "selected"
                  ? "#07565A"
                  : style === "trailing" &&
                      ["default", "disabled"].includes(states) &&
                      (states === "disabled" || type === "neutral")
                    ? "#858585"
                    : (sizes === "medium" &&
                          states === "focus" &&
                          style === "trailing" &&
                          type === "primary") ||
                        (sizes === "small" &&
                          states === "focus" &&
                          style === "trailing" &&
                          type === "primary") ||
                        (sizes === "tiny" &&
                          states === "focus" &&
                          style === "trailing" &&
                          type === "primary") ||
                        (states === "default" &&
                          style === "trailing" &&
                          type === "primary") ||
                        (states === "hover" &&
                          style === "trailing" &&
                          type === "primary")
                      ? "#1849D6"
                      : undefined
        }
        className={masterOutlineSizeLargeClassName}
        divClassName={masterOutlineDivClassName}
        info61Color={
          (states === "default" &&
            style === "leading" &&
            type === "secondary") ||
          (states === "focus" && style === "leading" && type === "secondary") ||
          (states === "hover" && style === "leading" && type === "secondary")
            ? "#0EACB4"
            : (states === "focus" &&
                  style === "leading" &&
                  type === "neutral") ||
                (states === "hover" &&
                  style === "leading" &&
                  type === "neutral") ||
                (states === "selected" &&
                  style === "leading" &&
                  type === "neutral")
              ? "#0B0B0B"
              : style === "leading" &&
                  type === "primary" &&
                  states === "selected"
                ? "#0C246B"
                : style === "leading" &&
                    type === "secondary" &&
                    states === "selected"
                  ? "#07565A"
                  : style === "leading" &&
                      ["default", "disabled"].includes(states) &&
                      (states === "disabled" || type === "neutral")
                    ? "#858585"
                    : (sizes === "medium" &&
                          states === "focus" &&
                          style === "leading" &&
                          type === "primary") ||
                        (sizes === "small" &&
                          states === "focus" &&
                          style === "leading" &&
                          type === "primary") ||
                        (sizes === "tiny" &&
                          states === "focus" &&
                          style === "leading" &&
                          type === "primary") ||
                        (states === "default" &&
                          style === "leading" &&
                          type === "primary") ||
                        (states === "hover" &&
                          style === "leading" &&
                          type === "primary")
                      ? "#1849D6"
                      : undefined
        }
        leading={["standard", "trailing"].includes(style) ? false : undefined}
        size={
          sizes === "medium"
            ? "medium"
            : sizes === "small"
              ? "small"
              : sizes === "tiny"
                ? "tiny"
                : "large"
        }
        text={masterOutlineText}
        trailing={["leading", "standard"].includes(style) ? false : undefined}
      />
    </div>
  );
};

Outline.propTypes = {
  style: PropTypes.oneOf(["trailing", "standard", "leading"]),
  type: PropTypes.oneOf(["primary", "neutral", "secondary"]),
  sizes: PropTypes.oneOf(["large", "tiny", "medium", "small"]),
  states: PropTypes.oneOf([
    "default",
    "selected",
    "focus",
    "hover",
    "disabled",
  ]),
  masterOutlineText: PropTypes.string,
};
