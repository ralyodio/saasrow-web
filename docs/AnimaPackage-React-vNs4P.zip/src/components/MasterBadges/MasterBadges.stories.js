import { MasterBadges } from ".";

export default {
  title: "Components/MasterBadges",
  component: MasterBadges,

  argTypes: {
    size: {
      options: ["large", "tiny", "small"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    trailing: true,
    leading: true,
    text: "Badges",
    size: "large",
    className: {},
    labelTextClassName: {},
  },
};
