import { ManyUpload } from ".";

export default {
  title: "Components/ManyUpload",
  component: ManyUpload,

  argTypes: {
    states: {
      options: ["uploading", "hover", "default"],
      control: { type: "select" },
    },
    style: {
      options: ["base", "alt"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    states: "uploading",
    style: "base",
    className: {},
    frameClassName: {},
    textClassName: {},
    divClassName: {},
    divClassNameOverride: {},
    divClassName1: {},
    text: "jpg, png, or svg",
  },
};
