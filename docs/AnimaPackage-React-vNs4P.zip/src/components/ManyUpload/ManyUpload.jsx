/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { Backup } from "../../icons/Backup";
import { Divider } from "../Divider";
import { Outline } from "../Outline";
import "./style.css";

export const ManyUpload = ({
  states,
  style,
  className,
  icon = <Backup className="backup-1" />,
  frameClassName,
  textClassName,
  divClassName,
  divClassNameOverride,
  divClassName1,
  text = "jpg, png, or svg",
}) => {
  return (
    <div className={`many-upload states-${states} ${className}`}>
      {style === "base" && states === "default" && <>{icon}</>}

      {states === "default" && style === "alt" && (
        <div className="upload">
          <img className="vector" alt="Vector" src="/img/vector.svg" />

          <img className="vector-2" alt="Vector" src="/img/vector-1.svg" />

          <img className="vector-3" alt="Vector" src="/img/vector-2.svg" />

          <img className="vector-4" alt="Vector" src="/img/vector-3.svg" />

          <img className="vector-5" alt="Vector" src="/img/vector-4.svg" />

          <img className="vector-6" alt="Vector" src="/img/vector-5.svg" />

          <img className="vector-7" alt="Vector" src="/img/vector-6.svg" />

          <img className="vector-8" alt="Vector" src="/img/vector-7.svg" />
        </div>
      )}

      {states === "default" && (
        <div className={`frame-5 ${frameClassName}`}>
          {style === "base" && (
            <>
              <div className={`text ${textClassName}`}>
                <div className={`text-wrapper-18 ${divClassName}`}>
                  Drag your file(s) or
                </div>

                <div className={`text-wrapper-19 ${divClassNameOverride}`}>
                  browse
                </div>
              </div>

              <div className={`jpg-png-or-svg ${divClassName1}`}>{text}</div>
            </>
          )}

          {style === "alt" && (
            <>
              <div className="text">
                <p className="text-wrapper-18">
                  Drag your file(s) to start uploading
                </p>
              </div>

              <Divider
                borderWeight="w-text"
                className="divider-2"
                size="full"
                text="OR"
                variants="solid"
              />
              <Outline
                className="outline-instance"
                masterOutlineSizeLargeClassName="outline-2"
                masterOutlineText="Browse files"
                sizes="small"
                states="default"
                style="standard"
                type="primary"
              />
            </>
          )}
        </div>
      )}

      {(states === "uploading" || (states === "hover" && style === "alt")) && (
        <div className={`upload-2 states-0-${states} ${style}`}>
          {states === "hover" && (
            <>
              <img className="vector" alt="Vector" src="/img/vector.svg" />

              <img className="vector-2" alt="Vector" src="/img/vector-1.svg" />

              <img className="vector-3" alt="Vector" src="/img/vector-2.svg" />

              <img className="vector-4" alt="Vector" src="/img/vector-3.svg" />

              <img className="vector-5" alt="Vector" src="/img/vector-4.svg" />

              <img className="vector-6" alt="Vector" src="/img/vector-5.svg" />

              <img className="vector-7" alt="Vector" src="/img/vector-6.svg" />

              <img className="vector-8" alt="Vector" src="/img/vector-7.svg" />
            </>
          )}

          {style === "base" && (
            <div className="master-circle">
              <img
                className="content-area"
                alt="Content area"
                src="/img/contentarea.svg"
              />
            </div>
          )}

          {states === "uploading" && style === "alt" && <>Uploading...</>}
        </div>
      )}

      {style === "base" && states === "hover" && (
        <Backup className="backup-1" />
      )}

      {["hover", "uploading"].includes(states) && (
        <div className={`frame-6 states-1-${states} style-${style}`}>
          {["hover", "uploading"].includes(states) &&
            (states === "hover" || style === "alt") &&
            (states === "uploading" || style === "base") &&
            ["base", "alt"].includes(style) && (
              <>
                <div className="text-2">
                  {style === "base" && (
                    <>
                      <div className="text-wrapper-18">
                        Drag your file(s) or
                      </div>

                      <div className="text-wrapper-19">browse</div>
                    </>
                  )}

                  {states === "uploading" && <div className="master-linear" />}
                </div>

                <div className="jpg-png-or-svg-2">
                  {style === "base" && <>{text}</>}

                  {states === "uploading" && <>60%</>}
                </div>
              </>
            )}

          {states === "hover" && style === "alt" && (
            <>
              <div className="text">
                <p className="text-wrapper-18">
                  Drag your file(s) to start uploading
                </p>
              </div>

              <Divider
                borderWeight="w-text"
                className="divider-2"
                size="full"
                text="OR"
                variants="solid"
              />
              <Outline
                className="outline-instance"
                masterOutlineSizeLargeClassName="outline-2"
                masterOutlineText="Browse files"
                sizes="small"
                states="default"
                style="standard"
                type="primary"
              />
            </>
          )}

          {states === "uploading" && style === "base" && (
            <>
              <div className="text-wrapper-18">Uploading...</div>

              <Outline
                className="outline-instance"
                masterOutlineDivClassName="outline-4"
                masterOutlineSizeLargeClassName="outline-3"
                masterOutlineText="Cancel"
                sizes="small"
                states="default"
                style="standard"
                type="neutral"
              />
            </>
          )}
        </div>
      )}

      {style === "base" && states === "hover" && (
        <div className="drag-example">
          <div className="drag">
            <div className="document">
              <img className="vector-9" alt="Vector" src="/img/vector-16.svg" />

              <img
                className="vector-10"
                alt="Vector"
                src="/img/vector-17.svg"
              />
            </div>

            <div className="text-wrapper-20">theprojetks-design-tokens.zip</div>
          </div>

          <div className="drag-2">
            <img className="vector-11" alt="Vector" src="/img/vector-1-1.svg" />

            <img className="vector-12" alt="Vector" src="/img/vector-18.svg" />
          </div>
        </div>
      )}

      {(states === "uploading" || (states === "hover" && style === "alt")) && (
        <div className={`drag-example-2 states-4-${states} style-2-${style}`}>
          {states === "hover" && (
            <>
              <div className="drag">
                <div className="document">
                  <img
                    className="vector-9"
                    alt="Vector"
                    src="/img/vector-16.svg"
                  />

                  <img
                    className="vector-10"
                    alt="Vector"
                    src="/img/vector-17.svg"
                  />
                </div>

                <div className="text-wrapper-20">
                  theprojetks-design-tokens.zip
                </div>
              </div>

              <div className="drag-2">
                <img
                  className="vector-11"
                  alt="Vector"
                  src="/img/vector-1-1.svg"
                />

                <img
                  className="vector-12"
                  alt="Vector"
                  src="/img/vector-18.svg"
                />
              </div>
            </>
          )}

          {style === "base" && <>60%</>}

          {states === "uploading" && style === "alt" && (
            <Outline
              className="outline-instance"
              masterOutlineDivClassName="outline-4"
              masterOutlineSizeLargeClassName="outline-3"
              masterOutlineText="Cancel"
              sizes="small"
              states="default"
              style="standard"
              type="neutral"
            />
          )}
        </div>
      )}
    </div>
  );
};

ManyUpload.propTypes = {
  states: PropTypes.oneOf(["uploading", "hover", "default"]),
  style: PropTypes.oneOf(["base", "alt"]),
  text: PropTypes.string,
};
