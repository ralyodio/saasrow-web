import React from "react";
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import { Community } from "./screens/Community";
import { Submit } from "./screens/Submit";

const router = createBrowserRouter([
  {
    path: "/*",
    element: <Submit />,
  },
  {
    path: "/submit",
    element: <Submit />,
  },
  {
    path: "/community",
    element: <Community />,
  },
]);

export const App = () => {
  return <RouterProvider router={router} />;
};
