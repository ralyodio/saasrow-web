import React from "react";
import { DivWrapper } from "../../components/DivWrapper";
import { Divider } from "../../components/Divider";
import { GroupWrapper } from "../../components/GroupWrapper";
import { ManyUpload } from "../../components/ManyUpload";
import { PricingCard } from "../../components/PricingCard";
import { Title } from "../../components/Title";
import { UploadUrl } from "../../components/UploadUrl";
import { Backup2 } from "../../icons/Backup2";
import { HighlightOff3 } from "../../icons/HighlightOff3";
import "./style.css";

export const Submit = () => {
  return (
    <div className="submit">
      <div className="group-5">
        <div className="rectangle-2" />

        <div className="rectangle-3" />

        <div className="rectangle-4" />

        <div className="rectangle-5" />
      </div>

      <GroupWrapper className="group-102" divClassName="group-102-instance" />
      <DivWrapper className="group-39900" />
      <PricingCard
        className="pricing-card-instance"
        hasCardContent={false}
        kind="default"
        version="ver-1"
      />
      <Title
        className="title-instance"
        desc
        div={false}
        masterGeneralDesc={false}
        masterGeneralHasDiv={false}
        masterGeneralIcon1={false}
        type="single-trailing"
      />
      <div className="group-6">
        <div className="basic-info-wrapper">
          <div className="basic-info">
            <div className="text-field">
              <div className="frame-8">
                <div className="label-2">Title</div>
              </div>

              <div className="text-field-2">
                <div className="inputs">
                  <div className="element-2">Enter your Title</div>
                </div>
              </div>
            </div>

            <div className="text-field-3">
              <div className="frame-8">
                <div className="label-3">URL</div>
              </div>

              <div className="text-field-4">
                <div className="inputs-2">
                  <div className="text-wrapper-23">Enter your URL</div>
                </div>
              </div>
            </div>

            <div className="text-field-5">
              <div className="frame-8">
                <div className="label-3">Description</div>
              </div>

              <div className="text-field-6">
                <div className="inputs-3">
                  <div className="text-wrapper-23">Enter your Description</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="group-7">
          <ManyUpload
            className="many-upload-instance"
            divClassName="design-component-instance-node-2"
            divClassName1="many-upload-4"
            divClassNameOverride="many-upload-3"
            frameClassName="design-component-instance-node"
            icon={<Backup2 className="backup-2" />}
            states="default"
            style="base"
            text="Max 10 MB files are allowed"
            textClassName="many-upload-2"
          />
          <p className="p">Only support .jpg, .png and .svg</p>

          <Divider
            borderWeight="w-text"
            className="divider-3"
            divClassName="design-component-instance-node-2"
            lineClassName="divider-4"
            lineClassNameOverride="divider-4"
            size="full"
            text="OR"
            variants="solid"
          />
          <UploadUrl
            className="upload-URL-instance"
            outlineMasterOutlineDivClassName="upload-URL-3"
            outlineMasterOutlineSizeLargeClassName="upload-URL-4"
            rowClassName="upload-URL-2"
            states="default"
          />
          <div className="frame-wrapper">
            <div className="frame-9">
              <img className="image" alt="Image" src="/img/image-4.png" />

              <div className="text-5">
                <div className="text-wrapper-24">Zoom.jpg</div>

                <div className="text-wrapper-25">500kb</div>
              </div>

              <div className="highlight-off-wrapper">
                <HighlightOff3 className="highlight-off" />
              </div>
            </div>
          </div>
        </div>

        <button className="button-4">
          <div className="text-wrapper-26">Submit</div>
        </button>
      </div>
    </div>
  );
};
