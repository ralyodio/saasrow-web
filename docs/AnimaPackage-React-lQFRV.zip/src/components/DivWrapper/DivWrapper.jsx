/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";
import "./style.css";

export const DivWrapper = ({ className }) => {
  return (
    <div className={`div-wrapper ${className}`}>
      <div className="group-4">
        <p className="p">
          A community of software makers and marketers helping each other grow.
        </p>
      </div>

      <div className="text-wrapper-5">Product</div>

      <div className="text-wrapper-6">Posts</div>

      <div className="text-wrapper-7">Last Activity</div>

      <div className="group-5">
        <div className="text-wrapper-8">Github Discussion</div>

        <div className="text-wrapper-9">Feelingsurf discussion</div>

        <div className="text-wrapper-10">FineVoice discussion</div>

        <div className="text-wrapper-11">EasyCheck.io discussion</div>

        <div className="text-wrapper-12">ProjectionLab discussion</div>

        <div className="text-wrapper-13">1</div>

        <div className="text-wrapper-14">5</div>

        <div className="text-wrapper-15">1</div>

        <div className="text-wrapper-16">1</div>

        <div className="text-wrapper-17">16</div>

        <div className="text-wrapper-18">8 hours</div>

        <div className="text-wrapper-19">22 hours</div>

        <div className="text-wrapper-20">1 Day</div>

        <div className="text-wrapper-21">1 Day</div>

        <div className="text-wrapper-22">2 Days</div>

        <div className="group-6">
          <div className="ellipse" />

          <img className="image" alt="Image" />
        </div>

        <img className="img" alt="Image" />

        <div className="group-7" />

        <img className="image-2" alt="Image" />

        <div className="group-8">
          <div className="ellipse-2" />

          <img className="image-3" alt="Image" />
        </div>
      </div>

      <div className="group-9">
        <div className="text-wrapper-8">Github Discussion</div>

        <div className="text-wrapper-9">Feelingsurf discussion</div>

        <div className="text-wrapper-10">FineVoice discussion</div>

        <div className="text-wrapper-11">EasyCheck.io discussion</div>

        <div className="text-wrapper-12">ProjectionLab discussion</div>

        <div className="text-wrapper-13">1</div>

        <div className="text-wrapper-14">5</div>

        <div className="text-wrapper-15">1</div>

        <div className="text-wrapper-16">1</div>

        <div className="text-wrapper-17">16</div>

        <div className="text-wrapper-18">8 hours</div>

        <div className="text-wrapper-19">22 hours</div>

        <div className="text-wrapper-20">1 Day</div>

        <div className="text-wrapper-21">1 Day</div>

        <div className="text-wrapper-22">2 Days</div>

        <div className="group-6">
          <div className="ellipse" />

          <img className="image" alt="Image" />
        </div>

        <img className="img" alt="Image" />

        <div className="group-7" />

        <img className="image-2" alt="Image" />

        <div className="group-8">
          <div className="ellipse-2" />

          <img className="image-3" alt="Image" />
        </div>
      </div>

      <div className="group-10">
        <div className="text-wrapper-8">Github Discussion</div>

        <div className="text-wrapper-9">Feelingsurf discussion</div>

        <div className="text-wrapper-10">FineVoice discussion</div>

        <div className="text-wrapper-11">EasyCheck.io discussion</div>

        <div className="text-wrapper-12">ProjectionLab discussion</div>

        <div className="text-wrapper-13">1</div>

        <div className="text-wrapper-14">5</div>

        <div className="text-wrapper-15">1</div>

        <div className="text-wrapper-16">1</div>

        <div className="text-wrapper-17">16</div>

        <div className="text-wrapper-18">8 hours</div>

        <div className="text-wrapper-19">22 hours</div>

        <div className="text-wrapper-20">1 Day</div>

        <div className="text-wrapper-21">1 Day</div>

        <div className="text-wrapper-22">2 Days</div>

        <div className="group-6">
          <div className="ellipse" />

          <img className="image" alt="Image" />
        </div>

        <img className="img" alt="Image" />

        <div className="group-7" />

        <img className="image-2" alt="Image" />

        <div className="group-8">
          <div className="ellipse-2" />

          <img className="image-3" alt="Image" />
        </div>
      </div>

      <div className="group-11">
        <div className="group-12">
          <div className="ellipse-3" />

          <div className="text-wrapper-23">1</div>
        </div>

        <div className="text-wrapper-24">2</div>

        <div className="text-wrapper-25">15</div>

        <div className="text-wrapper-26">...</div>
      </div>
    </div>
  );
};
