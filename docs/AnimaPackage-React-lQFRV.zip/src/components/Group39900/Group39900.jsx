/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const Group39900 = ({ className, line = "/img/line-2-2.svg" }) => {
  return (
    <div className={`group-39900 ${className}`}>
      <div className="group-13">
        <p className="element-torahweb-all">
          © 2019 SaaSRow. All rights reserved.
        </p>

        <div className="terms-of-service-pri">
          Terms of
          Service&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Privacy
          Policy
        </div>

        <img className="line" alt="Line" src={line} />

        <div className="links">
          <div className="text-wrapper-27">Discover</div>

          <div className="text-wrapper-28">About us</div>

          <div className="text-wrapper-29">Explore</div>

          <div className="books">News</div>
        </div>

        <img className="social" alt="Social" src="/img/social-2.png" />
      </div>

      <img
        className="wiresniff-logo-2"
        alt="Wiresniff logo"
        src="/img/wiresniff-logo-1-1.png"
      />
    </div>
  );
};

Group39900.propTypes = {
  line: PropTypes.string,
};
