import { Group39900 } from ".";

export default {
  title: "Components/Group39900",
  component: Group39900,
};

export const Default = {
  args: {
    className: {},
    line: "/img/line-2-2.svg",
  },
};
