import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { Community } from "./screens/Community";

createRoot(document.getElementById("app")).render(
  <StrictMode>
    <Community />
  </StrictMode>,
);
