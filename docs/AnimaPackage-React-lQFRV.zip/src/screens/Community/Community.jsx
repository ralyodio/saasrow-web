import React from "react";
import { DivWrapper } from "../../components/DivWrapper";
import { Group39900 } from "../../components/Group39900";
import { GroupWrapper } from "../../components/GroupWrapper";
import "./style.css";

export const Community = () => {
  return (
    <div className="community">
      <GroupWrapper
        className="group-102"
        divClassName="group-102-instance"
        divClassNameOverride="design-component-instance-node"
      />
      <DivWrapper className="group-39906" />
      <Group39900 className="group-39900-instance" line="/img/line-2-3.svg" />
    </div>
  );
};
