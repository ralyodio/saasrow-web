import React from "react";
import { DivWrapper } from "../../components/DivWrapper";
import { GroupWrapper } from "../../components/GroupWrapper";
import "./style.css";

export const Submit = () => {
  return (
    <div className="submit">
      <div className="group-28">
        <div className="rectangle-8" />

        <div className="rectangle-9" />

        <div className="rectangle-10" />

        <div className="rectangle-11" />
      </div>

      <GroupWrapper className="group-29" divClassName="group-30" />
      <DivWrapper className="group-39900-instance" />
      <div className="pricing-card" />

      <div className="title">
        <div className="master-general">
          <div className="wrapper">
            <div className="left" />

            <div className="right" />
          </div>
        </div>
      </div>

      <div className="group-31">
        <div className="basic-info-wrapper">
          <div className="basic-info">
            <div className="text-field">
              <div className="frame">
                <div className="label">Title</div>
              </div>

              <div className="text-field-2">
                <div className="inputs">
                  <div className="element">Enter your Title</div>
                </div>
              </div>
            </div>

            <div className="text-field-3">
              <div className="frame">
                <div className="label-2">URL</div>
              </div>

              <div className="text-field-4">
                <div className="inputs-2">
                  <div className="text-wrapper-20">Enter your URL</div>
                </div>
              </div>
            </div>

            <div className="text-field-5">
              <div className="frame">
                <div className="label-2">Description</div>
              </div>

              <div className="text-field-6">
                <div className="inputs-3">
                  <div className="text-wrapper-20">Enter your Description</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="group-32">
          <div className="many-upload">
            <img className="backup" alt="Backup" src="/img/backup-2.svg" />

            <div className="frame-2">
              <div className="text">
                <div className="text-wrapper-21">Drag your file(s) or</div>

                <div className="text-wrapper-22">browse</div>
              </div>

              <p className="jpg-png-or-svg">Max 10 MB files are allowed</p>
            </div>
          </div>

          <p className="desc">Only support .jpg, .png and .svg</p>

          <div className="divider">
            <div className="line-2" />

            <div className="text-2">OR</div>

            <div className="line-2" />
          </div>

          <div className="upload-URL">
            <div className="URL">Add file URL</div>

            <div className="outline">
              <div className="master-outline">
                <div className="button">Upload</div>
              </div>
            </div>
          </div>

          <div className="frame-wrapper">
            <div className="frame-3">
              <img className="image-9" alt="Image" src="/img/image-4.png" />

              <div className="text-3">
                <div className="text-wrapper-23">Zoom.jpg</div>

                <div className="text-wrapper-24">500kb</div>
              </div>

              <div className="action">
                <img
                  className="highlight-off"
                  alt="Highlight off"
                  src="/img/highlight-off-3.svg"
                />
              </div>
            </div>
          </div>
        </div>

        <button className="button-2">
          <div className="text-wrapper-25">Submit</div>
        </button>
      </div>
    </div>
  );
};
