export { Detailed } from "./Detailed";
