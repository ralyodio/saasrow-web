import React from "react";
import { DivWrapper } from "../../components/DivWrapper";
import { Group117 } from "../../components/Group117";
import { GroupWrapper } from "../../components/GroupWrapper";
import "./style.css";

export const Detailed = () => {
  return (
    <div className="detailed">
      <div className="group-18">
        <div className="rectangle-4" />

        <div className="rectangle-5" />

        <div className="rectangle-6" />

        <div className="rectangle-7" />
      </div>

      <GroupWrapper className="group-102" divClassName="group-102-instance" />
      <DivWrapper className="group-39900" />
      <div className="group-19">
        <div className="group-20">
          <div className="group-21">
            <div className="text-wrapper-17">Videos</div>
          </div>

          <img className="image-2" alt="Image" src="/img/image-13-1.png" />

          <img className="image-3" alt="Image" src="/img/image-14-1.png" />

          <img className="image-4" alt="Image" src="/img/image-15-1.png" />
        </div>
      </div>

      <div className="group-22">
        <div className="group-23">
          <div className="text-wrapper-18">Screenshots and images</div>
        </div>

        <div className="group-24">
          <img className="image-5" alt="Image" src="/img/image-11-1.png" />

          <img className="image-6" alt="Image" src="/img/image-12-1.png" />
        </div>

        <img className="group-25" alt="Group" src="/img/group-39914-1.png" />
      </div>

      <div className="group-26">
        <div className="group-27">
          <div className="text-wrapper-19">Reviews</div>
        </div>

        <img className="image-7" alt="Image" src="/img/image-16-1.png" />

        <img className="image-8" alt="Image" src="/img/image-17-1.png" />
      </div>

      <Group117
        className="group-117-instance"
        groupClassName="design-component-instance-node"
      />
    </div>
  );
};
