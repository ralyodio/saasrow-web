import React from "react";
import { DivWrapper } from "../../components/DivWrapper";
import { GroupWrapper } from "../../components/GroupWrapper";
import "./style.css";

export const Community = () => {
  return (
    <div className="community">
      <GroupWrapper
        className="group-34"
        divClassName="group-35"
        divClassNameOverride="group-33"
      />
      <div className="group-36">
        <div className="group-37">
          <p className="p">
            A community of software makers and marketers helping each other
            grow.
          </p>
        </div>

        <div className="text-wrapper-26">Product</div>

        <div className="text-wrapper-27">Posts</div>

        <div className="text-wrapper-28">Last Activity</div>

        <div className="group-38">
          <div className="text-wrapper-29">Github Discussion</div>

          <div className="text-wrapper-30">Feelingsurf discussion</div>

          <div className="text-wrapper-31">FineVoice discussion</div>

          <div className="text-wrapper-32">EasyCheck.io discussion</div>

          <div className="text-wrapper-33">ProjectionLab discussion</div>

          <div className="text-wrapper-34">1</div>

          <div className="text-wrapper-35">5</div>

          <div className="text-wrapper-36">1</div>

          <div className="text-wrapper-37">1</div>

          <div className="text-wrapper-38">16</div>

          <div className="text-wrapper-39">8 hours</div>

          <div className="text-wrapper-40">22 hours</div>

          <div className="text-wrapper-41">1 Day</div>

          <div className="text-wrapper-42">1 Day</div>

          <div className="text-wrapper-43">2 Days</div>

          <div className="group-39">
            <div className="ellipse" />

            <img className="image-10" alt="Image" />
          </div>

          <img className="image-11" alt="Image" />

          <div className="group-40" />

          <img className="image-12" alt="Image" />

          <div className="group-41">
            <div className="ellipse-2" />

            <img className="image-13" alt="Image" />
          </div>
        </div>

        <div className="group-42">
          <div className="text-wrapper-29">Github Discussion</div>

          <div className="text-wrapper-30">Feelingsurf discussion</div>

          <div className="text-wrapper-31">FineVoice discussion</div>

          <div className="text-wrapper-32">EasyCheck.io discussion</div>

          <div className="text-wrapper-33">ProjectionLab discussion</div>

          <div className="text-wrapper-34">1</div>

          <div className="text-wrapper-35">5</div>

          <div className="text-wrapper-36">1</div>

          <div className="text-wrapper-37">1</div>

          <div className="text-wrapper-38">16</div>

          <div className="text-wrapper-39">8 hours</div>

          <div className="text-wrapper-40">22 hours</div>

          <div className="text-wrapper-41">1 Day</div>

          <div className="text-wrapper-42">1 Day</div>

          <div className="text-wrapper-43">2 Days</div>

          <div className="group-39">
            <div className="ellipse" />

            <img className="image-10" alt="Image" />
          </div>

          <img className="image-11" alt="Image" />

          <div className="group-40" />

          <img className="image-12" alt="Image" />

          <div className="group-41">
            <div className="ellipse-2" />

            <img className="image-13" alt="Image" />
          </div>
        </div>

        <div className="group-43">
          <div className="text-wrapper-29">Github Discussion</div>

          <div className="text-wrapper-30">Feelingsurf discussion</div>

          <div className="text-wrapper-31">FineVoice discussion</div>

          <div className="text-wrapper-32">EasyCheck.io discussion</div>

          <div className="text-wrapper-33">ProjectionLab discussion</div>

          <div className="text-wrapper-34">1</div>

          <div className="text-wrapper-35">5</div>

          <div className="text-wrapper-36">1</div>

          <div className="text-wrapper-37">1</div>

          <div className="text-wrapper-38">16</div>

          <div className="text-wrapper-39">8 hours</div>

          <div className="text-wrapper-40">22 hours</div>

          <div className="text-wrapper-41">1 Day</div>

          <div className="text-wrapper-42">1 Day</div>

          <div className="text-wrapper-43">2 Days</div>

          <div className="group-39">
            <div className="ellipse" />

            <img className="image-10" alt="Image" />
          </div>

          <img className="image-11" alt="Image" />

          <div className="group-40" />

          <img className="image-12" alt="Image" />

          <div className="group-41">
            <div className="ellipse-2" />

            <img className="image-13" alt="Image" />
          </div>
        </div>

        <div className="group-44">
          <div className="group-45">
            <div className="ellipse-3" />

            <div className="text-wrapper-44">1</div>
          </div>

          <div className="text-wrapper-45">2</div>

          <div className="text-wrapper-46">15</div>

          <div className="text-wrapper-47">...</div>
        </div>
      </div>

      <DivWrapper className="group-46" line="/img/line-2-3.svg" />
    </div>
  );
};
