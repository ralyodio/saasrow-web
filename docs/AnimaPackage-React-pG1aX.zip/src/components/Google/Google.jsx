/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";
import { StarActiveGoogle11 } from "../../icons/StarActiveGoogle11";
import "./style.css";

export const Google = ({ className }) => {
  return (
    <div className={`google ${className}`}>
      <StarActiveGoogle11 className="star-active-google" />
      <StarActiveGoogle11 className="star-active-google-11" />
      <StarActiveGoogle11 className="star-active-google-21" />
      <StarActiveGoogle11 className="star-active-google-16" />
      <StarActiveGoogle11 className="star-active-google-11-instance" />
    </div>
  );
};
