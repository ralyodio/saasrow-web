import { Google } from ".";

export default {
  title: "Components/Google",
  component: Google,
};

export const Default = {
  args: {
    className: {},
  },
};
