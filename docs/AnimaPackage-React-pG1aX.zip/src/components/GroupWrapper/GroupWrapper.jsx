/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";
import { Group } from "../Group";
import "./style.css";

export const GroupWrapper = ({
  className,
  divClassName,
  divClassNameOverride,
}) => {
  return (
    <div className={`group-wrapper ${className}`}>
      <div className="div">
        <div className="group-2">
          <div className="group-3">
            <div className="text-wrapper">Tags</div>

            <div className={`text-wrapper-2 ${divClassName}`}>Apps</div>

            <div className={`text-wrapper-3 ${divClassNameOverride}`}>
              Community
            </div>

            <div className="text-wrapper-4">Get Featured</div>
          </div>

          <Group
            className="group-instance"
            divClassName="group-2-instance"
            text="Sign in"
          />
        </div>
      </div>

      <img
        className="wiresniff-logo"
        alt="Wiresniff logo"
        src="/img/wiresniff-logo-1-1.png"
      />
    </div>
  );
};
