import { GroupWrapper } from ".";

export default {
  title: "Components/GroupWrapper",
  component: GroupWrapper,
};

export const Default = {
  args: {
    className: {},
    divClassName: {},
    divClassNameOverride: {},
  },
};
