import { Group117 } from ".";

export default {
  title: "Components/Group117",
  component: Group117,
};

export const Default = {
  args: {
    className: {},
    groupClassName: {},
  },
};
