/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";
import { Google } from "../Google";
import "./style.css";

export const Group117 = ({ className, groupClassName }) => {
  return (
    <div className={`group-117 ${className}`}>
      <div className="group-5" />

      <div className="group-6">
        <div className="group-7">
          <div className="group-8">
            <img className="image" alt="Image" />

            <div className="text-wrapper-8">Zoom</div>
          </div>
        </div>

        <div className="equip-your-team-with-wrapper">
          <p className="equip-your-team-with">
            Equip your team with tools designed to collaborate, connect, and
            engage with teammates and customers, no matter where you’re located,
            all in one platform.
            <br />
            Equip your team with the communication and collaboration tools they
            crave including team chat, video conferencing, phone, email, and
            calendar all in one platform.
            <br />
            Share, connect, and engage with teammates no matter where you’re
            located with the tools you need like docs, notes, whiteboards, and
            video clips.
            <br />
            Make teamwork more meaningful across hybrid teams with modern
            collaboration solutions designed for teams like yours like meeting
            room systems, digital signage, and employee communications.
          </p>
        </div>

        <div className="platform-mobile-wrapper">
          <p className="platform-mobile">
            <span className="span">Platform</span>

            <span className="text-wrapper-9">
              : Mobile&nbsp;&nbsp;|&nbsp;&nbsp;Desktop
            </span>
          </p>
        </div>

        <div className="group-9">
          <Google className="stars-google" />
          <div className="group-10">
            <div className="text-wrapper-10">5.0</div>
          </div>

          <div className="group-11">
            <div className="text-wrapper-11">(24 Reviews)</div>

            <div className="text-wrapper-12">Post a review</div>
          </div>
        </div>

        <div className="overlap-group">
          <div className="group-12">
            <div className="group-13">
              <div className="rectangle" />

              <div className="text-wrapper-13">Software</div>
            </div>

            <div className="group-14">
              <div className="rectangle-2" />

              <div className="text-wrapper-14">Visti Website</div>
            </div>
          </div>

          <div className="group-15">
            <div className="group-16">
              <div className="rectangle-3" />

              <div className="text-wrapper-15">Online</div>
            </div>
          </div>
        </div>

        <div className="group-17">
          <img className="vector" alt="Vector" />

          <img className="vector-2" alt="Vector" />

          <div className="text-wrapper-16">144</div>
        </div>
      </div>

      <div className={`vector-wrapper ${groupClassName}`}>
        <img className="vector-3" alt="Vector" />
      </div>
    </div>
  );
};
